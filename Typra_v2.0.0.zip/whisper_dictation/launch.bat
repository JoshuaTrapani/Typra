@echo off
start "" /B wscript.exe "%~dp0Typra.vbs"
