@echo off
TITLE Typra Setup
cd /d "%~dp0"

REM ── Find Python 3.11 ──────────────────────────────────────────────────────
py -3.11 --version >NUL 2>&1
IF ERRORLEVEL 1 (
    ECHO Python 3.11 not found.
    ECHO Download from: https://www.python.org/downloads/release/python-3119/
    PAUSE & EXIT /B 1
)

REM ── Create venv if missing ────────────────────────────────────────────────
IF NOT EXIST ".venv\Scripts\activate.bat" (
    ECHO Creating virtual environment...
    py -3.11 -m venv .venv
    IF ERRORLEVEL 1 ( ECHO Failed to create venv. & PAUSE & EXIT /B 1 )
)

REM ── Install dependencies if needed ────────────────────────────────────────
CALL .venv\Scripts\activate.bat
python -c "import PyQt6" >NUL 2>&1
IF ERRORLEVEL 1 (
    ECHO Installing dependencies - this may take a few minutes...
    pip install --upgrade pip >NUL 2>&1
    pip install -r requirements.txt
    IF ERRORLEVEL 1 ( ECHO Install failed. & PAUSE & EXIT /B 1 )
    ECHO Done.
)

REM ── Kill any old instance ─────────────────────────────────────────────────
taskkill /F /IM pythonw.exe /FI "WINDOWTITLE eq Typra*" >NUL 2>&1
timeout /t 1 /nobreak >NUL

REM ── Launch silently via VBS (no console) ──────────────────────────────────
wscript.exe "%~dp0Typra.vbs"
