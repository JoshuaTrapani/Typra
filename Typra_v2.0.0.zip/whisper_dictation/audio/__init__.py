# audio/__init__.py
from .recorder import AudioRecorder, MicrophoneInfo
