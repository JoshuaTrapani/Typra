# stt/subprocess_worker.py
"""
Standalone transcription subprocess.
Protocol:
  LOAD <model_size> <compute_type> <device>
  TRANSCRIBE <language> <prompt_b64> <audio_b64>
  QUIT
"""
import sys, base64, traceback

def main():
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)
    model = None

    for raw in sys.stdin:
        line = raw.strip()
        if not line:
            continue

        if line == "QUIT":
            break

        elif line.startswith("LOAD "):
            parts        = line.split(" ", 3)
            model_size   = parts[1] if len(parts) > 1 else "base"
            compute_type = parts[2] if len(parts) > 2 else "auto"
            device       = parts[3] if len(parts) > 3 else "cpu"
            try:
                from faster_whisper import WhisperModel
                model = WhisperModel(
                    model_size, device=device,
                    compute_type=compute_type,
                    cpu_threads=2, num_workers=1,
                )
                print("READY", flush=True)
            except Exception:
                print(f"ERROR {traceback.format_exc()}", flush=True)

        elif line.startswith("TRANSCRIBE "):
            if model is None:
                print("ERROR model not loaded", flush=True)
                continue
            try:
                parts    = line.split(" ", 3)
                language = parts[1]
                prompt   = base64.b64decode(parts[2]).decode("utf-8") if len(parts) > 2 else ""
                b64_data = parts[3] if len(parts) > 3 else ""

                import numpy as np
                audio = np.frombuffer(base64.b64decode(b64_data), dtype=np.float32)

                kwargs = dict(
                    language=language,
                    beam_size=1,
                    best_of=1,
                    temperature=0.0,
                    without_timestamps=True,
                    word_timestamps=False,
                )
                if prompt:
                    kwargs["initial_prompt"] = prompt

                # No VAD filter — let the worker's silence detection gate input
                segs, _ = model.transcribe(audio, **kwargs)
                text = " ".join(s.text.strip() for s in segs).strip()

                if text:
                    print(f"TEXT {base64.b64encode(text.encode()).decode()}", flush=True)
                else:
                    print("EMPTY", flush=True)

            except Exception:
                print(f"ERROR {traceback.format_exc()}", flush=True)

        else:
            print(f"ERROR unknown command: {line[:60]}", flush=True)

if __name__ == "__main__":
    main()
