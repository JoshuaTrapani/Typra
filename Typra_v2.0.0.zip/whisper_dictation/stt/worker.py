# stt/worker.py
"""
TranscriptionWorker: QThread consuming audio, applying voice commands
and optional LLM post-processing, emitting final text.
"""
from __future__ import annotations
import queue, re, time
import numpy as np
from PyQt6.QtCore import QThread, pyqtSignal

from audio.recorder import AudioRecorder
from config.settings import HALLUCINATION_PHRASES, Settings
from stt.transcriber import Transcriber
from stt.voice_commands import process_commands, CommandResult


class TranscriptionWorker(QThread):
    text_ready      = pyqtSignal(str)
    command_delete  = pyqtSignal()
    status_changed  = pyqtSignal(str)
    error_occurred  = pyqtSignal(str)

    def __init__(self, recorder: AudioRecorder, transcriber: Transcriber,
                 settings: Settings, parent=None) -> None:
        super().__init__(parent)
        self._recorder    = recorder
        self._transcriber = transcriber
        self._settings    = settings
        self._active      = False
        self._llm         = None

    def start_transcribing(self) -> None:
        print("[Worker] start_transcribing()")
        self._active = True

    def stop_transcribing(self) -> None:
        print("[Worker] stop_transcribing()")
        self._active = False

    def run(self) -> None:
        print("[Worker] Thread started")
        sr            = self._settings.sample_rate
        block_samples = 1024

        while not self.isInterruptionRequested():
            if not self._active:
                try: self._recorder.audio_queue.get(timeout=0.05)
                except queue.Empty: pass
                continue

            self.status_changed.emit("listening")
            buf:        list[np.ndarray] = []
            silence_n   = 0
            has_speech  = False
            max_samples = int(self._settings.chunk_seconds * sr)
            sil_thresh  = int(self._settings.silence_seconds * sr)
            rms_thresh  = self._settings.silence_threshold

            print(f"[Worker] Listening — chunk={self._settings.chunk_seconds}s "
                  f"rms_thresh={rms_thresh} sil_sec={self._settings.silence_seconds}s")

            while self._active and not self.isInterruptionRequested():
                try:
                    chunk = self._recorder.audio_queue.get(timeout=0.05)
                except queue.Empty:
                    continue
                buf.append(chunk)
                rms    = float(np.sqrt(np.mean(chunk ** 2)))
                silent = rms < rms_thresh
                if silent:
                    silence_n += block_samples
                else:
                    silence_n = 0
                    has_speech = True
                total = sum(c.shape[0] for c in buf)
                if has_speech and (silence_n >= sil_thresh or total >= max_samples):
                    print(f"[Worker] Flushing {total} samples")
                    self._flush(buf, sr)
                    buf = []; silence_n = 0; has_speech = False

            if buf and has_speech:
                self._flush(buf, sr)
            self.status_changed.emit("idle")

        print("[Worker] Thread exiting")

    def _flush(self, buf: list[np.ndarray], sr: int) -> None:
        audio    = np.concatenate(buf)
        duration = len(audio) / sr
        print(f"[Worker] _flush: {duration:.2f}s lang={self._settings.language}")
        self.status_changed.emit("processing")

        if not self._transcriber.is_loaded:
            print("[Worker] Transcriber not loaded — skipping")
            self.status_changed.emit("listening"); return

        hotwords = self._settings.custom_hotwords.strip()
        raw = self._transcriber.transcribe(
            audio,
            language=self._settings.language,
            initial_prompt=hotwords if hotwords else "",
        )
        print(f"[Worker] Transcriber returned: {raw!r}")

        if not raw:
            self.status_changed.emit("listening"); return

        if self._settings.filter_hallucinations:
            if raw.strip().lower() in HALLUCINATION_PHRASES:
                print(f"[Worker] Hallucination filtered: {raw!r}")
                self.status_changed.emit("listening"); return

        raw = re.sub(r"  +", " ", raw.strip())

        if self._settings.voice_commands_enabled:
            result: CommandResult = process_commands(raw, self._settings.language)
            if result.delete_last:
                self.command_delete.emit()
                self.status_changed.emit("listening"); return
            text = result.text
        else:
            text = raw

        if not text:
            self.status_changed.emit("listening"); return

        if self._settings.llm_enabled and self._settings.llm_tone != "none":
            text = self._apply_llm(text)

        if text:
            print(f"[Worker] Emitting: {text!r}")
            self.text_ready.emit(text)
        self.status_changed.emit("listening")

    def _apply_llm(self, text: str) -> str:
        if self._llm is None:
            from stt.llm_processor import LLMProcessor
            self._llm = LLMProcessor()
        if not self._llm.is_ready():
            return text
        return self._llm.process(text, tone=self._settings.llm_tone)
