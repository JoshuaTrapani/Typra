# stt/llm_processor.py
"""
Local LLM post-processing via llama-cpp-python.
Gemma 4 E2B (pre-installed) and Llama 3.2 1B available.
All models run fully offline via GGUF — no API key needed.
"""
from __future__ import annotations
import json, os, subprocess, sys, tempfile, threading
from pathlib import Path
from typing import Callable, Optional

_MODEL_DIR = Path.home() / ".whisper_dictation" / "llm_models"

# Available models (GGUF, llama-cpp-python, fully offline)
LLM_MODELS: dict[str, dict] = {
    "gemma4-e2b-q4": {
        "name": "Gemma 4 E2B (2.5 GB)",
        "desc": "Google · Great quality · Fast on CPU · Recommended · Pre-installed",
        "url":  ("https://huggingface.co/bartowski/google_gemma-4-E2B-it-GGUF"
                 "/resolve/main/google_gemma-4-E2B-it-Q4_K_M.gguf"),
        "file": "gemma4-e2b-q4.gguf",
    },
    "llama32-1b-q4": {
        "name": "Llama 3.2 1B (0.8 GB)",
        "desc": "Meta · Smallest and fastest · Basic cleanup",
        "url":  ("https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF"
                 "/resolve/main/Llama-3.2-1B-Instruct-Q4_K_M.gguf"),
        "file": "llama32-1b-q4.gguf",
    },
}
_DEFAULT_MODEL = "gemma4-e2b-q4"


def _model_path(model_id: str) -> Path:
    info = LLM_MODELS.get(model_id, LLM_MODELS[_DEFAULT_MODEL])
    return _MODEL_DIR / info["file"]


_SYSTEM_PROMPTS = {
    "cleanup": (
        "You are a transcription editor. Fix grammar and punctuation. "
        "Remove filler words (um, uh, like, you know). Return only the corrected text."
    ),
    "casual": (
        "Rewrite this speech transcription in a friendly, casual tone. "
        "Remove fillers. Return only the rewritten text."
    ),
    "professional": (
        "Rewrite this transcription formally with correct grammar and punctuation. "
        "Remove filler words. Return only the rewritten text."
    ),
    "concise": (
        "Summarise this transcription as concisely as possible without losing meaning. "
        "Remove all fillers. Return only the concise version."
    ),
}


class LLMProcessor:
    """Subprocess-isolated LLM post-processing. Supports Phi-3, Llama 3.2, Gemma 4."""

    def __init__(self, model_id: str = _DEFAULT_MODEL) -> None:
        self._model_id = model_id if model_id in LLM_MODELS else _DEFAULT_MODEL
        self._lock     = threading.Lock()

    # ── Availability ──────────────────────────────────────────────────

    def model_path(self) -> Path:
        return _model_path(self._model_id)

    def model_downloaded(self) -> bool:
        p = self.model_path()
        return p.exists() and p.stat().st_size > 1_000_000

    @staticmethod
    def model_downloaded_for(model_id: str) -> bool:
        p = _model_path(model_id)
        return p.exists() and p.stat().st_size > 1_000_000

    @staticmethod
    def llama_cpp_available() -> bool:
        try:
            import llama_cpp  # noqa
            return True
        except Exception:
            return False

    def is_ready(self) -> bool:
        return self.model_downloaded() and self.llama_cpp_available()

    # ── Download ──────────────────────────────────────────────────────

    def download_model(self, progress_cb: Optional[Callable[[int,int], None]] = None,
                       model_id: Optional[str] = None) -> bool:
        mid  = model_id or self._model_id
        info = LLM_MODELS.get(mid, LLM_MODELS[_DEFAULT_MODEL])
        dest = _MODEL_DIR / info["file"]
        _MODEL_DIR.mkdir(parents=True, exist_ok=True)
        tmp  = Path(str(dest) + ".part")
        try:
            import urllib.request
            req = urllib.request.Request(
                info["url"],
                headers={"User-Agent": "Mozilla/5.0 Typra/2.5"},
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                total   = int(resp.headers.get("Content-Length", 0))
                received = 0
                chunk_sz = 65536   # 64 KB chunks
                with open(tmp, "wb") as f:
                    while True:
                        chunk = resp.read(chunk_sz)
                        if not chunk:
                            break
                        f.write(chunk)
                        received += len(chunk)
                        if progress_cb:
                            if total > 0:
                                progress_cb(received, total)
                            else:
                                # No Content-Length: report bytes received, estimate
                                progress_cb(received, max(received, received))
            tmp.rename(dest)
            return True
        except Exception as exc:
            print(f"[LLM] Download failed: {exc}")
            if tmp.exists(): tmp.unlink()
            if dest.exists(): dest.unlink()
            return False

    # ── Processing ────────────────────────────────────────────────────

    def process(self, text: str, tone: str = "cleanup",
                use_gpu: bool = False) -> str:
        if not text.strip() or tone == "none" or not self.is_ready():
            return text
        system_prompt = _SYSTEM_PROMPTS.get(tone, _SYSTEM_PROMPTS["cleanup"])
        model_file    = str(self.model_path())
        result = self._run_subprocess(text, system_prompt, model_file, use_gpu)
        return result if result else text

    def _run_subprocess(self, text: str, system_prompt: str,
                        model_file: str, use_gpu: bool) -> str:
        n_gpu = -1 if use_gpu else 0   # -1 = offload all layers to GPU
        script = f"""
import sys, json
from llama_cpp import Llama
model = Llama(
    model_path={model_file!r},
    n_ctx=512, n_threads=2,
    n_gpu_layers={n_gpu},
    verbose=False,
)
response = model.create_chat_completion(
    messages=[
        {{"role":"system","content":{system_prompt!r}}},
        {{"role":"user","content":{text!r}}},
    ],
    max_tokens=256, temperature=0.1,
)
print(json.dumps(response["choices"][0]["message"]["content"].strip()))
"""
        try:
            tmp = tempfile.NamedTemporaryFile(
                mode="w", suffix=".py", delete=False, encoding="utf-8")
            tmp.write(script); tmp.close()
            r = subprocess.run([sys.executable, tmp.name],
                               capture_output=True, text=True, timeout=30)
            os.unlink(tmp.name)
            if r.returncode == 0 and r.stdout.strip():
                return json.loads(r.stdout.strip())
        except Exception as exc:
            print(f"[LLM] Subprocess error: {exc}")
        return ""
