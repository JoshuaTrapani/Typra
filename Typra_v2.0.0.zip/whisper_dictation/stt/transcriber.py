# stt/transcriber.py
"""
Transcriber: runs faster-whisper in a subprocess.
- GPU is probed end-to-end (load + dummy transcription). If it fails, falls back to CPU.
- subprocess stderr is drained continuously so it never blocks.
- Full error text is logged, not truncated.
- On transcription ERROR, automatically retries once with CPU fallback.
"""
from __future__ import annotations
import base64, json, os, subprocess, sys, threading
from pathlib import Path
from typing import Callable, Optional
import numpy as np


def _get_worker_script() -> list:
    if getattr(sys, "frozen", False):
        return [sys.executable, "--worker"]
    return [sys.executable, str(Path(__file__).parent / "subprocess_worker.py")]


MODEL_INFO = {
    "tiny":           {"size": "~75 MB",  "label": "Fastest · Lower accuracy"},
    "base":           {"size": "~145 MB", "label": "Fast · Good accuracy"},
    "small":          {"size": "~465 MB", "label": "Balanced · Better accuracy"},
    "medium":         {"size": "~1.5 GB", "label": "Slow · High accuracy"},
    "large-v3-turbo": {"size": "~1.6 GB", "label": "Best quality · Requires patience"},
}


class Transcriber:
    def __init__(self, model_size: str = "base", gpu: bool = False) -> None:
        self.model_size    = model_size
        self.gpu           = gpu
        self._proc: Optional[subprocess.Popen] = None
        self._loaded       = False
        self._compute_type = "auto"

    @staticmethod
    def faster_whisper_available() -> bool:
        try:
            import ctranslate2, faster_whisper  # noqa
            return True
        except Exception:
            return False

    @staticmethod
    def cuda_available() -> bool:
        try:
            import ctranslate2
            return ctranslate2.get_cuda_device_count() > 0
        except Exception:
            return False

    def load(self, status_cb: Optional[Callable[[str], None]] = None) -> None:
        ct = self._probe_compute_type(status_cb)
        if ct is None:
            raise RuntimeError("No working compute_type found for ctranslate2.")
        self._compute_type = ct
        device = "cuda" if self.gpu else "cpu"
        if status_cb:
            status_cb(f"Loading '{self.model_size}' model ({device})…")
        print(f"[Transcriber] Starting worker (model={self.model_size}, compute={ct}, gpu={self.gpu})")
        self._start_worker()
        self._send(f"LOAD {self.model_size} {ct} {device}")
        response = self._readline(timeout=300)
        if response == "READY":
            self._loaded = True
            print("[Transcriber] Worker ready.")
            if status_cb:
                status_cb("Model ready — start speaking!")
        else:
            self._kill_worker()
            raise RuntimeError(f"Worker error: {response}")

    def shutdown(self) -> None:
        if self._proc:
            try: self._send("QUIT")
            except Exception: pass
            try: self._proc.wait(timeout=3)
            except Exception: pass
            self._kill_worker()

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    def transcribe(self, audio: np.ndarray, language: str = "en",
                   initial_prompt: str = "") -> str:
        if not self._loaded or audio is None or len(audio) == 0:
            return ""
        return self._subprocess_transcribe(audio, language, initial_prompt)

    # ── Subprocess communication ──────────────────────────────────────

    def _start_worker(self) -> None:
        self._proc = subprocess.Popen(
            _get_worker_script(),
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True,
            bufsize=1, encoding="utf-8",
        )
        # Drain stderr continuously — prevents pipe buffer filling and blocking
        def _drain_stderr():
            try:
                for line in self._proc.stderr:
                    print(f"[Worker-stderr] {line.rstrip()}")
            except Exception:
                pass
        threading.Thread(target=_drain_stderr, daemon=True, name="WorkerStderr").start()

    def _kill_worker(self) -> None:
        if self._proc:
            try: self._proc.kill()
            except Exception: pass
            self._proc = None
        self._loaded = False

    def _send(self, line: str) -> None:
        if self._proc and self._proc.stdin:
            self._proc.stdin.write(line + "\n")
            self._proc.stdin.flush()

    def _readline(self, timeout: float = 30.0) -> str:
        if not self._proc: return "ERROR no process"
        result = [""]
        done   = threading.Event()
        def _read():
            try:
                result[0] = self._proc.stdout.readline().strip()
            except Exception as e:
                result[0] = f"ERROR {e}"
            finally:
                done.set()
        threading.Thread(target=_read, daemon=True).start()
        return result[0] if done.wait(timeout) else "ERROR timeout"

    def _subprocess_transcribe(self, audio: np.ndarray,
                                language: str, initial_prompt: str) -> str:
        # Restart dead worker
        if self._proc is None or self._proc.poll() is not None:
            print("[Transcriber] Worker died — restarting with CPU…")
            self.gpu = False
            self._compute_type = "float32"
            try:
                self._start_worker()
                self._send(f"LOAD {self.model_size} {self._compute_type} cpu")
                if self._readline(120) != "READY":
                    self._kill_worker(); return ""
            except Exception as e:
                print(f"[Transcriber] Restart failed: {e}"); return ""

        result = self._do_transcribe(audio, language, initial_prompt)

        # If GPU transcription errored, fall back to CPU and retry once
        if result is None:
            if self.gpu:
                print("[Transcriber] GPU transcription failed — falling back to CPU")
                self._kill_worker()
                self.gpu           = False
                self._compute_type = "float32"
                self._start_worker()
                self._send(f"LOAD {self.model_size} {self._compute_type} cpu")
                if self._readline(120) == "READY":
                    result = self._do_transcribe(audio, language, initial_prompt)
                else:
                    self._kill_worker()
                    return ""
            if result is None:
                return ""

        return result

    def _do_transcribe(self, audio: np.ndarray,
                       language: str, initial_prompt: str) -> Optional[str]:
        """Send TRANSCRIBE, return text or None on error."""
        try:
            b64        = base64.b64encode(audio.astype(np.float32).tobytes()).decode("ascii")
            prompt_b64 = base64.b64encode(initial_prompt.encode()).decode("ascii")
            self._send(f"TRANSCRIBE {language} {prompt_b64} {b64}")
            resp = self._readline(60)
            if resp.startswith("TEXT "):
                return base64.b64decode(resp[5:]).decode("utf-8")
            if resp == "EMPTY":
                return ""
            if resp.startswith("ERROR"):
                # Log the full error (not truncated)
                print(f"[Transcriber] Subprocess error:\n{resp[6:]}")
                return None   # signals "error occurred, consider fallback"
            print(f"[Transcriber] Unexpected response: {resp[:100]}")
            return ""
        except Exception as e:
            print(f"[Transcriber] _do_transcribe exception: {e}")
            return None

    # ── Probe ──────────────────────────────────────────────────────────

    def _probe_compute_type(self, status_cb=None) -> Optional[str]:
        # GPU path: test end-to-end (load + transcription), not just availability
        if self.gpu:
            if status_cb: status_cb("Testing GPU transcription…")
            if self.cuda_available():
                if self._probe_one("float16", "cuda", status_cb):
                    return "float16"
                print("[Transcriber] GPU probe failed — using CPU")
            else:
                print("[Transcriber] CUDA not available — using CPU")
            self.gpu = False

        if status_cb: status_cb("Checking CPU compatibility…")
        for ct in ["auto", "float32", "int8"]:
            if self._probe_one(ct, "cpu", status_cb):
                return ct

        return None

    def _probe_one(self, compute_type: str, device: str,
                   status_cb=None) -> bool:
        """Run a full load+transcribe probe in an isolated subprocess."""
        probe = (
            "import sys, json, numpy as np\n"
            "from faster_whisper import WhisperModel\n"
            f"try:\n"
            f"    m = WhisperModel({self.model_size!r}, device={device!r},\n"
            f"        compute_type={compute_type!r}, cpu_threads=2, num_workers=1)\n"
            f"    dummy = np.zeros(16000, dtype=np.float32)\n"
            f"    list(m.transcribe(dummy, language='en')[0])\n"
            f"    print(json.dumps({{'ok': True}}))\n"
            f"    sys.exit(0)\n"
            f"except Exception as e:\n"
            f"    print(json.dumps({{'ok': False, 'error': str(e)}}))\n"
            f"    sys.exit(1)\n"
        )
        import tempfile
        tmp = tempfile.NamedTemporaryFile(mode="w", suffix=".py",
                                          delete=False, encoding="utf-8")
        tmp.write(probe); tmp.close()
        print(f"[Transcriber] Probing compute={compute_type} device={device}…")
        if status_cb: status_cb(f"Testing {device} ({compute_type})…")
        try:
            r = subprocess.run(
                [sys.executable, tmp.name],
                capture_output=True, text=True, timeout=120,
            )
            out = r.stdout.strip()
            print(f"[Transcriber] Probe result: exit={r.returncode} out={out[:80]}")
            if r.returncode == 0 and out:
                d = json.loads(out)
                if d.get("ok"):
                    print(f"[Transcriber] Using compute={compute_type} device={device}")
                    return True
        except subprocess.TimeoutExpired:
            print(f"[Transcriber] Probe {compute_type}/{device} timed out")
        except Exception as e:
            print(f"[Transcriber] Probe {compute_type}/{device} error: {e}")
        finally:
            try: os.unlink(tmp.name)
            except Exception: pass
        return False
