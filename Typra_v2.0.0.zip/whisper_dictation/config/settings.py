# config/settings.py
from __future__ import annotations
import json
from pathlib import Path

DEFAULTS: dict = {
    # ── Core ──────────────────────────────────────────────────────────
    "language":           "en",
    "model_size":         "base",
    "microphone_index":   None,
    "hotkey":             "ctrl+shift+space",
    "recording_mode":     "toggle",      # toggle only

    # ── Audio / transcription ──────────────────────────────────────────
    "chunk_seconds":      3.0,
    "silence_threshold":  0.008,
    "silence_seconds":    0.7,
    "sample_rate":        16000,
    "add_trailing_space": True,
    "filter_hallucinations": True,

    # ── LLM post-processing ──────────────────────────────────────────
    "llm_enabled":        False,
    "llm_tone":           "cleanup",
    "llm_model_id":       "gemma4-e2b-q4",     # cleanup | casual | professional | concise

    # ── Voice commands ────────────────────────────────────────────────
    "voice_commands_enabled": True,

    # ── Custom dictionary / hotwords ──────────────────────────────────
    "custom_hotwords":    "",            # newline-separated words

    # ── GPU acceleration ──────────────────────────────────────────────
    "gpu_enabled":        False,

    # ── UI ────────────────────────────────────────────────────────────
    "window_always_on_top": True,
    "start_minimized":    True,
}

HALLUCINATION_PHRASES = {
    "thank you.", "thank you", "thanks for watching.",
    "thanks for watching", "please subscribe.", ".", "...", "you",
}


class Settings:
    def __init__(self) -> None:
        self._dir  = Path.home() / ".whisper_dictation"
        self._file = self._dir / "settings.json"
        self._data: dict = DEFAULTS.copy()
        self._load()

    def _load(self) -> None:
        if self._file.exists():
            try:
                saved = json.loads(self._file.read_text(encoding="utf-8"))
                self._data.update({k: v for k, v in saved.items() if k in DEFAULTS})
            except Exception as exc:
                print(f"[Settings] Load error: {exc}")

    def save(self) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)
        try:
            self._file.write_text(
                json.dumps(self._data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except Exception as exc:
            print(f"[Settings] Save error: {exc}")

    def get(self, key: str, default=None):
        return self._data.get(key, default)

    def set(self, key: str, value) -> None:
        if key in DEFAULTS:
            self._data[key] = value
            self.save()

    def __getitem__(self, key): return self._data[key]
    def __setitem__(self, key, value): self.set(key, value)

    # Convenience properties
    @property
    def language(self) -> str:        return self._data["language"]
    @property
    def model_size(self) -> str:      return self._data["model_size"]
    @property
    def sample_rate(self) -> int:     return int(self._data["sample_rate"])
    @property
    def microphone_index(self):       return self._data["microphone_index"]
    @property
    def chunk_seconds(self) -> float: return float(self._data["chunk_seconds"])
    @property
    def silence_threshold(self) -> float: return float(self._data["silence_threshold"])
    @property
    def silence_seconds(self) -> float:   return float(self._data["silence_seconds"])
    @property
    def add_trailing_space(self) -> bool: return bool(self._data["add_trailing_space"])
    @property
    def filter_hallucinations(self) -> bool: return bool(self._data["filter_hallucinations"])
    @property
    def window_always_on_top(self) -> bool: return bool(self._data["window_always_on_top"])
    @property
    def recording_mode(self) -> str:  return "toggle"  # hold-to-talk removed
    @property
    def llm_enabled(self) -> bool:    return bool(self._data.get("llm_enabled", False))
    @property
    def llm_tone(self) -> str:        return self._data.get("llm_tone", "cleanup")
    @property
    def gpu_enabled(self) -> bool:    return bool(self._data.get("gpu_enabled", False))
    @property
    def voice_commands_enabled(self) -> bool:
        return bool(self._data.get("voice_commands_enabled", True))
    @property
    def custom_hotwords(self) -> str: return self._data.get("custom_hotwords", "")
