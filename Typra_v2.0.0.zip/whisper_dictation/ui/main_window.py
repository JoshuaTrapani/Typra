# ui/main_window.py
"""
AppController: Typra v2 invisible coordinator.
Wires: recorder, transcriber, worker, LLM, history, hotkey,
       overlay, settings, tray, voice commands.
"""
from __future__ import annotations
import sys, os, time
from pathlib import Path

from PyQt6.QtCore import QObject, Qt, QThread, QTimer, pyqtSignal, pyqtSlot
from PyQt6.QtGui import QCloseEvent, QColor, QIcon, QPainter, QPixmap
from PyQt6.QtWidgets import QApplication, QMessageBox
from PyQt6.QtCore import QProcess
from PyQt6.QtWidgets import QSystemTrayIcon as _QSTray

from audio.recorder import AudioRecorder
from config.settings import Settings
from db.history import HistoryStore
from input.hotkey import HotkeyManager
from input.typer import TextTyper
from stt.transcriber import Transcriber
from stt.worker import TranscriptionWorker
from ui.overlay import RecordingOverlay
from ui.settings_window import SettingsWindow
from ui.history_window import HistoryWindow
from ui.tray import SystemTray

_ASSETS         = Path(__file__).parent.parent / "assets"
_ICO_DARK       = _ASSETS / "typra_dark.ico"
_ICO_LIGHT      = _ASSETS / "typra_light.ico"


def _is_dark() -> bool:
    if sys.platform != "win32": return True
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize")
        v, _ = winreg.QueryValueEx(k, "AppsUseLightTheme")
        winreg.CloseKey(k); return v == 0
    except Exception: return True


def make_app_icon() -> QIcon:
    ico = _ICO_DARK if _is_dark() else _ICO_LIGHT
    if ico.exists():
        icon = QIcon(str(ico))
        if not icon.isNull(): return icon
    icon = QIcon()
    for size in (16, 32, 48):
        px = QPixmap(size, size); px.fill(QColor(0,0,0,0))
        p = QPainter(px); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setBrush(QColor(46,213,115)); p.setPen(QColor(0,0,0,0))
        m = size//8; p.drawEllipse(m,m,size-2*m,size-2*m); p.end()
        icon.addPixmap(px)
    return icon


def _make_logo_pixmap(square_size: int = 40) -> QPixmap:
    ico = _ICO_DARK if _is_dark() else _ICO_LIGHT
    px = QPixmap(square_size, square_size); px.fill(QColor(0,0,0,0))
    if ico.exists():
        loaded = QPixmap(str(ico))
        if not loaded.isNull():
            scaled = loaded.scaled(square_size, square_size,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation)
            x=(square_size-scaled.width())//2; y=(square_size-scaled.height())//2
            p=QPainter(px); p.drawPixmap(x,y,scaled); p.end()
    return px


class ModelLoader(QThread):
    status_update = pyqtSignal(str)
    finished_ok   = pyqtSignal()
    finished_err  = pyqtSignal(str)

    def __init__(self, transcriber: Transcriber, parent=None):
        super().__init__(parent); self._t = transcriber

    def run(self):
        import traceback
        try:
            self._t.load(status_cb=self.status_update.emit)
            self.finished_ok.emit()
        except Exception as e:
            self.finished_err.emit(f"{type(e).__name__}: {e}\n\n{traceback.format_exc()}")


class AppController(QObject):

    def __init__(self, settings: Settings) -> None:
        super().__init__()
        self._settings    = settings
        self._recording   = False
        self._model_ready = False
        self._downloading = False
        self._saved_tone   = settings.get('llm_tone', 'none')  # tone at last app start
        self._session_buf  = []   # text chunks accumulated during one recording session
        self._last_text   = ""     # for "delete that"
        self._last_dark   = _is_dark()

        self._app_icon = make_app_icon()
        QApplication.instance().setWindowIcon(self._app_icon)

        self._recorder    = AudioRecorder(sample_rate=settings.sample_rate)
        self._transcriber = Transcriber(
            model_size=settings.model_size,
            gpu=settings.gpu_enabled,
        )
        self._typer   = TextTyper()
        self._hotkey  = HotkeyManager(
            hotkey_str=settings.get("hotkey", "ctrl+shift+space"),
        )
        self._worker  = TranscriptionWorker(
            recorder=self._recorder,
            transcriber=self._transcriber,
            settings=settings,
        )
        self._history = HistoryStore()
        self._overlay = RecordingOverlay()
        self._settings_win = SettingsWindow(settings, self._app_icon)
        self._history_win  = HistoryWindow(self._history, self._app_icon)
        self._tray    = SystemTray(app_icon=self._app_icon)

        self._wire()

    # ── Start ──────────────────────────────────────────────────────────

    def start(self) -> None:
        self._tray.show()
        self._tray.set_active_tone(self._settings.get('llm_tone', 'none'))
        self._worker.start()
        self._hotkey.start()
        self._typer.start_tracking(0)

        self._model_loader = ModelLoader(self._transcriber)
        self._model_loader.status_update.connect(self._on_loader_status)
        self._model_loader.finished_ok.connect(self._on_model_loaded)
        self._model_loader.finished_err.connect(self._on_model_error)
        self._model_loader.start()

        # Theme watcher
        self._theme_timer = QTimer()
        self._theme_timer.setInterval(3000)
        self._theme_timer.timeout.connect(self._check_theme)
        self._theme_timer.start()

        QTimer.singleShot(300, self._apply_taskbar_icon)

    # ── Wire ───────────────────────────────────────────────────────────

    def _wire(self) -> None:
        # Tray
        self._tray.toggle_recording.connect(self._toggle_recording)
        self._tray.open_settings.connect(self._open_settings)
        self._tray.open_history.connect(self._open_history)
        self._tray.quit_app.connect(self._quit)
        self._tray.tone_selected.connect(self._on_tone)

        # Overlay
        self._overlay.stop_requested.connect(self._stop_recording)

        # Hotkey
        self._hotkey.activated.connect(self._toggle_recording)

        # Audio level
        self._recorder.set_level_callback(self._overlay.set_level)

        # Worker
        self._worker.text_ready.connect(self._on_text_ready)
        self._worker.command_delete.connect(self._on_command_delete)
        self._worker.status_changed.connect(self._on_worker_status)

        # Settings signals
        self._settings_win.language_changed.connect(lambda _: None)
        self._settings_win.mic_changed.connect(self._on_mic_changed)
        self._settings_win.model_changed.connect(self._on_model_changed)
        self._settings_win.hotkey_changed.connect(self._on_hotkey_changed)
        self._settings_win.download_started.connect(self._on_download_started)
        self._settings_win.download_finished.connect(self._on_download_finished)

        # History re-paste
        self._history_win.paste_requested.connect(self._retype)

    # ── Recording ──────────────────────────────────────────────────────

    @pyqtSlot()
    def _toggle_recording(self) -> None:
        if not self._model_ready: return
        if self._recording: self._stop_recording()
        else: self._start_recording()

    @pyqtSlot()
    def _start_recording(self) -> None:
        if not self._model_ready or self._recording or self._downloading: return
        self._recording = True
        try:
            self._recorder.start(device_index=self._settings.microphone_index)
        except Exception as e:
            self._recording = False
            self._tray.showMessage("Typra: Mic Error", str(e), _QSTray.MessageIcon.Warning, 3000); return
        self._session_buf = []
        self._worker.start_transcribing()
        self._overlay.show_overlay()
        self._tray.update_recording_state(True)

    @pyqtSlot()
    def _stop_recording(self) -> None:
        if not self._recording: return
        self._recording = False
        self._worker.stop_transcribing()
        self._recorder.stop()
        self._overlay.hide_overlay()
        self._tray.update_recording_state(False)
        # Save entire session as one history entry
        if self._session_buf:
            full = " ".join(self._session_buf).strip()
            if full:
                self._history.add(
                    text=full,
                    language=self._settings.language,
                    tone=self._settings.llm_tone if self._settings.llm_enabled else "none",
                )
                if self._history_win.isVisible():
                    self._history_win.refresh()
            self._session_buf = []

    # ── Text handling ──────────────────────────────────────────────────

    @pyqtSlot(str)
    def _on_text_ready(self, text: str) -> None:
        if not text: return
        self._last_text = text
        self._typer.type_text(text,
            trailing_space=self._settings.add_trailing_space,
            restore_focus=True)
        # Accumulate in session buffer — saved to history when recording stops
        self._session_buf.append(text)

    @pyqtSlot()
    def _on_command_delete(self) -> None:
        """Delete the last typed text segment using backspace."""
        if not self._last_text:
            return
        try:
            from pynput.keyboard import Controller, Key
            kb = Controller()
            n = len(self._last_text) + (1 if self._settings.add_trailing_space else 0)
            for _ in range(n):
                kb.press(Key.backspace)
                kb.release(Key.backspace)
        except Exception as exc:
            print(f"[AppController] delete error: {exc}")
        self._last_text = ""

    @pyqtSlot(str)
    def _retype(self, text: str) -> None:
        self._typer.type_text(text, trailing_space=True, restore_focus=True)

    # ── Slots ──────────────────────────────────────────────────────────

    @pyqtSlot(str)
    def _on_loader_status(self, msg: str) -> None:
        self._tray.setToolTip(f"Typra: {msg}")

    @pyqtSlot()
    def _on_model_loaded(self) -> None:
        self._model_ready = True
        self._tray.set_model_ready()
        print("[Typra] Model ready.")

    @pyqtSlot(str)
    def _on_model_error(self, err: str) -> None:
        print(f"\n{'='*60}\nMODEL ERROR:\n{err}\n{'='*60}\n")
        self._tray.setToolTip("Typra: Model error")
        box = QMessageBox()
        box.setWindowTitle("Typra: Model Error")
        box.setWindowIcon(self._app_icon)
        box.setIcon(QMessageBox.Icon.Critical)
        box.setTextFormat(Qt.TextFormat.RichText)
        box.setWindowFlags(box.windowFlags()|Qt.WindowType.WindowStaysOnTopHint)
        box.setText(
            "<b>The AI model failed to load.</b><br><br>"
            "Fix: install <b>Microsoft Visual C++ Redistributable 2022 (x64)</b>:<br>"
            "<code>https://aka.ms/vs/17/release/vc_redist.x64.exe</code><br><br>"
            "Click <b>Show Details</b> for the full error.")
        box.setDetailedText(err); box.exec()

    @pyqtSlot(str)
    def _on_worker_status(self, status: str) -> None:
        self._overlay.set_status(status)

    @pyqtSlot(object)
    def _on_mic_changed(self, _) -> None:
        if self._recording: self._stop_recording()

    @pyqtSlot(str)
    def _on_model_changed(self, model: str) -> None:
        pass  # setting already saved; user restarts via tray

    @pyqtSlot(str, str)
    def _on_hotkey_changed(self, hotkey: str, mode: str) -> None:
        self._hotkey.update(hotkey)

    @pyqtSlot(str)
    def _on_tone(self, tone: str) -> None:
        self._settings.set("llm_tone", tone)
        self._tray.set_active_tone(tone)
        if tone != self._saved_tone:
            self._tray.showMessage(
                "Typra: Tone changed",
                "Quit and reopen Typra for this tone to take effect.",
                self._app_icon, 4000)

    # ── Settings / History ─────────────────────────────────────────────

    @pyqtSlot()
    def _on_download_started(self) -> None:
        self._downloading = True
        if self._recording:
            self._stop_recording()
        self._tray.setToolTip("Typra: Downloading model — recording disabled")
        print("[Typra] Download started — recording blocked")

    @pyqtSlot()
    def _on_download_finished(self) -> None:
        self._downloading = False
        self._tray.setToolTip("Typra: Ready  (Ctrl+Shift+Space)")
        print("[Typra] Download finished — recording re-enabled")

    def _open_settings(self) -> None:
        self._settings_win.show()
        self._settings_win.raise_()
        self._settings_win.activateWindow()

    def _open_history(self) -> None:
        self._history_win.refresh()
        self._history_win.show()
        self._history_win.raise_()
        self._history_win.activateWindow()

    # ── Theme ──────────────────────────────────────────────────────────

    @pyqtSlot()
    def _check_theme(self) -> None:
        dark = _is_dark()
        if dark != self._last_dark:
            self._last_dark = dark
            self._app_icon  = make_app_icon()
            QApplication.instance().setWindowIcon(self._app_icon)
            self._tray.setIcon(self._app_icon)
            self._settings_win.setWindowIcon(self._app_icon)
            self._history_win.setWindowIcon(self._app_icon)
            self._settings_win.refresh_theme()
            QTimer.singleShot(100, self._apply_taskbar_icon)

    def _apply_taskbar_icon(self) -> None:
        if sys.platform != "win32": return
        try:
            import ctypes, tempfile, os
            ico = _ICO_DARK if _is_dark() else _ICO_LIGHT
            if not ico.exists(): return
            tmp = tempfile.NamedTemporaryFile(suffix=".ico", delete=False)
            tmp.write(ico.read_bytes()); tmp.close()
            IMAGE_ICON=1; LR_LOADFROMFILE=0x10; WM_SETICON=0x80
            h32=ctypes.windll.user32.LoadImageW(None,tmp.name,IMAGE_ICON,32,32,LR_LOADFROMFILE)
            h16=ctypes.windll.user32.LoadImageW(None,tmp.name,IMAGE_ICON,16,16,LR_LOADFROMFILE)
            for win in [self._settings_win, self._overlay, self._history_win]:
                try:
                    hwnd=int(win.winId())
                    if h32: ctypes.windll.user32.SendMessageW(hwnd,WM_SETICON,1,h32)
                    if h16: ctypes.windll.user32.SendMessageW(hwnd,WM_SETICON,0,h16)
                except Exception: pass
            os.unlink(tmp.name)
        except Exception as e: print(f"[Icon] {e}")

    # ── Quit ───────────────────────────────────────────────────────────

    def _quit(self) -> None:
        if self._recording: self._stop_recording()
        for fn in [
            lambda: (self._worker.stop_transcribing(),
                     self._worker.requestInterruption(),
                     self._worker.quit(), self._worker.wait(2000)),
            lambda: self._transcriber.shutdown(),
            lambda: self._hotkey.stop(),
            lambda: self._typer.stop_tracking(),
            lambda: self._theme_timer.stop(),
        ]:
            try: fn()
            except Exception: pass
        QApplication.quit()


MainWindow = AppController
