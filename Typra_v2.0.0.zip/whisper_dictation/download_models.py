"""
download_models.py — pre-downloads Gemma 4 E2B during installation.
Called by the NSIS installer after pip install completes.
"""
import sys, os, urllib.request, urllib.error
from pathlib import Path

MODEL_DIR  = Path.home() / ".whisper_dictation" / "llm_models"
MODEL_URL  = ("https://huggingface.co/bartowski/google_gemma-4-E2B-it-GGUF"
              "/resolve/main/google_gemma-4-E2B-it-Q4_K_M.gguf")
MODEL_FILE = MODEL_DIR / "gemma4-e2b-q4.gguf"
MIN_SIZE   = 100_000_000   # 100 MB — partial file guard

def _open_url(url: str):
    """Open URL following redirects, with no read timeout."""
    headers = {"User-Agent": "Mozilla/5.0 Typra/2.5"}
    # Follow up to 10 redirects manually so we keep our headers
    for _ in range(10):
        req  = urllib.request.Request(url, headers=headers)
        resp = urllib.request.urlopen(req)   # no timeout — download can take 20+ min
        code = resp.getcode()
        if code in (301, 302, 303, 307, 308):
            url = resp.headers.get("Location", url)
            resp.close()
            continue
        return resp
    raise RuntimeError("Too many redirects")

def main():
    MODEL_DIR.mkdir(parents=True, exist_ok=True)

    if MODEL_FILE.exists() and MODEL_FILE.stat().st_size > MIN_SIZE:
        print("Gemma 4 E2B already present — skipping download.", flush=True)
        sys.exit(0)

    tmp = Path(str(MODEL_FILE) + ".part")
    print("Downloading Gemma 4 E2B (~2.5 GB)...", flush=True)
    print(f"Destination: {MODEL_FILE}", flush=True)

    try:
        resp  = _open_url(MODEL_URL)
        total = int(resp.headers.get("Content-Length") or 0)
        received = 0
        chunk_sz = 262144   # 256 KB chunks
        last_pct = -1

        with open(tmp, "wb") as f:
            while True:
                chunk = resp.read(chunk_sz)
                if not chunk:
                    break
                f.write(chunk)
                received += len(chunk)
                mb = received / 1_048_576
                if total > 0:
                    pct = int(received * 100 / total)
                    if pct != last_pct:
                        print(f"Progress: {mb:.0f} MB / {total/1_048_576:.0f} MB  ({pct}%)", flush=True)
                        last_pct = pct
                else:
                    # No Content-Length — report MB received
                    if int(mb) % 50 == 0 and int(mb) != int((received - chunk_sz) / 1_048_576):
                        print(f"Downloaded: {mb:.0f} MB", flush=True)

        resp.close()

        if received < MIN_SIZE:
            print(f"ERROR: Download too small ({received} bytes) — incomplete.", flush=True)
            tmp.unlink(missing_ok=True)
            sys.exit(1)

        tmp.rename(MODEL_FILE)
        print(f"Download complete: {MODEL_FILE.stat().st_size / 1_048_576:.0f} MB", flush=True)
        sys.exit(0)

    except Exception as e:
        print(f"ERROR: {e}", flush=True)
        tmp.unlink(missing_ok=True)
        sys.exit(1)

if __name__ == "__main__":
    main()
