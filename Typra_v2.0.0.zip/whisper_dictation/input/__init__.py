# input/__init__.py
from .typer import TextTyper
from .hotkey import HotkeyManager
