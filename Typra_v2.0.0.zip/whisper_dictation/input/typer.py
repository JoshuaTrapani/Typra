# input/typer.py
"""
TextTyper: types transcribed text into the currently focused window.

Now that the overlay uses WS_EX_NOACTIVATE (never steals focus),
the user's target window keeps focus throughout recording.
We simply type to whatever window has focus — no focus manipulation needed.

Uses pynput Controller.type() which calls SendInput internally and
handles full Unicode (umlauts, CJK, etc.) correctly.
"""
from __future__ import annotations
import threading
import time


class TextTyper:
    def __init__(self) -> None:
        self._lock = threading.Lock()

    def start_tracking(self, own_hwnd: int = 0) -> None:
        pass  # no longer needed

    def stop_tracking(self) -> None:
        pass

    def type_text(
        self,
        text: str,
        trailing_space: bool = True,
        restore_focus: bool = True,
    ) -> None:
        if not text:
            return
        full = text + (" " if trailing_space and not text.endswith(" ") else "")
        with self._lock:
            try:
                from pynput.keyboard import Controller
                Controller().type(full)
            except Exception as exc:
                print(f"[TextTyper] type error: {exc}")
