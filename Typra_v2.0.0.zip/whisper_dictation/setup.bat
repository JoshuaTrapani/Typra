@echo off
cd /d "%~dp0"

REM ── Find Python 3.11 ──────────────────────────────────────────────────────
SET PYEXE=

REM Try py launcher (handles all registered versions)
py -3.11 --version >NUL 2>&1
IF NOT ERRORLEVEL 1 (
    FOR /F "tokens=*" %%i IN ('py -3.11 -c "import sys; print(sys.executable)"') DO SET PYEXE=%%i
    GOTO :found_python
)

REM Try common per-user install location (InstallAllUsers=0)
IF EXIST "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
    SET PYEXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe
    GOTO :found_python
)

REM Try system-wide install location (InstallAllUsers=1)
IF EXIST "%PROGRAMFILES%\Python311\python.exe" (
    SET PYEXE=%PROGRAMFILES%\Python311\python.exe
    GOTO :found_python
)
IF EXIST "%PROGRAMFILES(X86)%\Python311\python.exe" (
    SET PYEXE=%PROGRAMFILES(X86)%\Python311\python.exe
    GOTO :found_python
)

REM Last resort: check PATH for any python3.11
where python3.11 >NUL 2>&1
IF NOT ERRORLEVEL 1 (
    FOR /F "tokens=*" %%i IN ('where python3.11') DO SET PYEXE=%%i
    GOTO :found_python
)

ECHO ERROR: Python 3.11 not found.
EXIT /B 1

:found_python
ECHO Using Python: %PYEXE%

REM ── Create virtual environment ────────────────────────────────────────────
IF NOT EXIST ".venv\Scripts\activate.bat" (
    ECHO Creating virtual environment...
    "%PYEXE%" -m venv .venv
    IF ERRORLEVEL 1 ( ECHO ERROR: venv creation failed. & EXIT /B 1 )
)

REM ── Verify pip exists ─────────────────────────────────────────────────────
IF NOT EXIST ".venv\Scripts\pip.exe" (
    ECHO ERROR: pip not found in venv.
    EXIT /B 1
)

REM ── Install dependencies ──────────────────────────────────────────────────
ECHO Installing dependencies...
".venv\Scripts\pip.exe" install --upgrade pip --quiet
".venv\Scripts\pip.exe" install -r requirements.txt
IF ERRORLEVEL 1 ( ECHO ERROR: pip install failed. & EXIT /B 1 )

ECHO Setup complete.
EXIT /B 0
