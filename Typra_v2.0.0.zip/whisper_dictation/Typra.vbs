' Typra silent launcher
Dim sDir, sPy, sMain, oShell
sDir  = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))
sPy   = sDir & ".venv\Scripts\pythonw.exe"
sMain = sDir & "main.py"
Set oShell = CreateObject("WScript.Shell")
oShell.CurrentDirectory = sDir
oShell.Run """" & sPy & """ """ & sMain & """", 0, False
