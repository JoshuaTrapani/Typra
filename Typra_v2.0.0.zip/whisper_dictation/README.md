# Whisper Dictation 🎙️

**Offline, local-first speech-to-text dictation for Windows.**  
Speak → Transcribe → Type into any app — entirely on-device, zero cloud.

Powered by [faster-whisper](https://github.com/SYSTRAN/faster-whisper) and [PyQt6](https://pypi.org/project/PyQt6/).

---

## Features

| Feature | Details |
|---|---|
| 🔒 Fully offline | No internet required after first model download |
| 🎙 Mic selection | Detects all Windows audio input devices |
| 🌍 Languages | English and German (easily extendable) |
| ⌨️ Auto-typing | Text is typed into your active application |
| 🔑 Global hotkey | `Ctrl + Shift + Space` — works from any app |
| 📊 Level meter | Live audio visualisation |
| 🖥 System tray | Minimises to tray; right-click to start/stop |
| 💾 Persistent settings | Saved to `~/.whisper_dictation/settings.json` |
| ⚡ CPU-only | No GPU required; int8 quantisation for speed |

---

## Quick Start

### 1 — Prerequisites

- Windows 10 / 11
- Python 3.10 or 3.11 (3.12+ may have compatibility issues with some libs)
- A working microphone

### 2 — Clone / download the project

```bat
git clone https://github.com/yourname/whisper-dictation.git
cd whisper-dictation
```

Or extract the zip archive.

### 3 — Create a virtual environment (recommended)

```bat
python -m venv .venv
.venv\Scripts\activate
```

### 4 — Install dependencies

```bat
pip install -r requirements.txt
```

> **First run only:** faster-whisper will download the Whisper model from
> Hugging Face (~145 MB for `base`, ~75 MB for `tiny`). This requires internet
> access **once**. All subsequent runs are completely offline.

### 5 — Run

```bat
python main.py
```

---

## Project Structure

```
whisper_dictation/
├── main.py                 # Entry point — creates Qt app & main window
│
├── config/
│   ├── __init__.py
│   └── settings.py         # JSON-backed persistent settings
│
├── audio/
│   ├── __init__.py
│   └── recorder.py         # sounddevice InputStream → audio queue
│
├── stt/
│   ├── __init__.py
│   ├── transcriber.py      # faster-whisper wrapper (CPU, int8)
│   └── worker.py           # QThread: drains queue, detects silence, transcribes
│
├── input/
│   ├── __init__.py
│   ├── typer.py            # pynput keyboard controller + Windows focus tracking
│   └── hotkey.py           # pynput GlobalHotKeys listener
│
└── ui/
    ├── __init__.py
    ├── audio_meter.py      # Custom QWidget level visualiser
    ├── main_window.py      # Main window — coordinates all components
    └── tray.py             # QSystemTrayIcon with context menu
```

---

## How It Works

```
Microphone
    │
    ▼  (sounddevice InputStream callback)
AudioRecorder.audio_queue  ──────────────────►  AudioMeter (RMS visualisation)
    │
    ▼  (TranscriptionWorker QThread)
 Accumulate audio chunks
    │
    ├── On silence > 0.7 s after speech  ──┐
    └── On buffer > 3 s                  ──┤
                                           ▼
                                   Transcriber.transcribe()
                                   (faster-whisper, CPU, int8)
                                           │
                                           ▼  (Qt signal, cross-thread safe)
                                   MainWindow._on_text_ready()
                                      │             │
                                      ▼             ▼
                               Transcript       TextTyper.type_text()
                               Preview Box      (pynput → SetForegroundWindow
                                                 → keyboard.Controller.type())
```

### Global Hotkey Flow

```
Any app in foreground
    │  User presses Ctrl+Shift+Space
    ▼
pynput.GlobalHotKeys (daemon thread)
    │  .activated signal (thread-safe Qt emit)
    ▼
MainWindow._toggle_recording()
    │
    └── Focus tracker already saved last non-app HWND
        so typing goes back to the correct window
```

---

## Configuration

Settings are saved automatically to `~/.whisper_dictation/settings.json`.

```json
{
  "language": "en",
  "model_size": "base",
  "microphone_index": null,
  "hotkey": "ctrl+shift+space",
  "chunk_seconds": 3.0,
  "silence_threshold": 0.008,
  "silence_seconds": 0.7,
  "sample_rate": 16000,
  "add_trailing_space": true,
  "start_minimized": false,
  "window_always_on_top": true,
  "filter_hallucinations": true
}
```

| Key | Description |
|---|---|
| `language` | `"en"` (English) or `"de"` (German) |
| `model_size` | `tiny` / `base` / `small` / `medium` — larger = more accurate, slower |
| `microphone_index` | Device index from sounddevice; `null` = system default |
| `chunk_seconds` | Max audio buffer before forced transcription (seconds) |
| `silence_threshold` | RMS level below which audio is considered silence (0.0–1.0) |
| `silence_seconds` | How long silence must last to trigger transcription |
| `filter_hallucinations` | Filter common Whisper noise-on-silence phrases |

### Changing the global hotkey

Edit `~/.whisper_dictation/settings.json` and set `"hotkey"` to your preferred combination, e.g. `"ctrl+alt+r"`.  
Supported modifiers: `ctrl`, `shift`, `alt`, `win`.  
Supported keys: `space`, `tab`, letters (`a`–`z`), `f1`–`f12`.

---

## Model Sizes

| Model | Size | RAM (approx) | Speed (CPU) | Accuracy |
|---|---|---|---|---|
| `tiny` | 75 MB | ~390 MB | Very fast | Lower |
| `base` | 145 MB | ~500 MB | Fast ✅ | Good |
| `small` | 465 MB | ~1 GB | Moderate | Better |
| `medium` | 1.5 GB | ~2.6 GB | Slow | High |

**Recommended for dictation:** `base` — best speed/accuracy trade-off on CPU.

---

## Troubleshooting

### "No microphones found"
- Check that Windows has microphone access enabled in Settings → Privacy → Microphone.
- Ensure your microphone is plugged in and not disabled in Sound settings.

### Hotkey not responding
- Some applications intercept `Ctrl+Shift+Space`; change to an alternative like `ctrl+alt+d`.
- Run as administrator if hotkeys are blocked by UAC-elevated apps.

### Text typed into wrong window
- Use the global hotkey rather than clicking the app button — this keeps focus in the target app.
- If using the button, ensure your target app had focus just before clicking.

### High latency / slow transcription
- Switch to `tiny` model for maximum speed.
- Reduce `chunk_seconds` to `2.0` (shorter segments transcribe faster).
- Increase `silence_threshold` slightly (e.g. `0.015`) to trigger earlier.

### Hallucinated phrases ("Thank you.", etc.)
- Enable `filter_hallucinations` (default: on).
- This occurs when there's too much silence in a chunk — speak continuously.

### "DLL load failed" errors on import
- Ensure you're using Python 3.10 or 3.11.
- Run `pip install pywin32` and then `python Scripts/pywin32_postinstall.py -install`.

---

## Dependencies

| Package | Purpose |
|---|---|
| `PyQt6` | GUI framework |
| `faster-whisper` | Local Whisper inference (CPU, int8) |
| `sounddevice` | Cross-platform audio input |
| `numpy` | Audio array manipulation |
| `pynput` | Global hotkeys + keyboard simulation |
| `pywin32` | Windows HWND focus management |

---

## Extending

### Adding a language
In `ui/main_window.py`, add to `_lang_combo`:
```python
self._lang_combo.addItem("Français (French)", "fr")
```
faster-whisper supports all languages Whisper supports.

### Adding a custom hotkey in UI
Expose a `QLineEdit` for hotkey input, call `self._hotkey.update_hotkey(new_key)`.

### Running at startup
Create a shortcut to `pythonw.exe main.py` in:
`%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup`

---

## License

MIT — free to use, modify, and distribute.
