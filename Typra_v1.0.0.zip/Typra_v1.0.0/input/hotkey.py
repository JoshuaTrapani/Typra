# input/hotkey.py
"""
Global hotkey listener using pynput.

Runs pynput's GlobalHotKeys listener in a daemon thread.
Emits a Qt signal when the configured hotkey is pressed.

Default hotkey: Ctrl + Shift + Space
"""

from __future__ import annotations

import threading
from typing import Callable, Optional

from PyQt6.QtCore import QObject, pyqtSignal


# Mapping from our config string format to pynput format
_KEY_MAP = {
    "ctrl": "<ctrl>",
    "shift": "<shift>",
    "alt": "<alt>",
    "win": "<cmd>",
    "space": "<space>",
    "tab": "<tab>",
    "f1": "<f1>",
    "f2": "<f2>",
    "f3": "<f3>",
    "f4": "<f4>",
    "f5": "<f5>",
    "f6": "<f6>",
    "f7": "<f7>",
    "f8": "<f8>",
    "f9": "<f9>",
    "f10": "<f10>",
    "f11": "<f11>",
    "f12": "<f12>",
}


def _to_pynput_key(key_str: str) -> str:
    """Convert 'ctrl+shift+space' → '<ctrl>+<shift>+<space>'."""
    parts = [p.strip().lower() for p in key_str.split("+")]
    return "+".join(_KEY_MAP.get(p, p) for p in parts)


class HotkeyManager(QObject):
    """Wraps pynput GlobalHotKeys and exposes a Qt signal."""

    #: Emitted whenever the hotkey is activated
    activated = pyqtSignal()

    def __init__(self, hotkey_str: str = "ctrl+shift+space", parent=None) -> None:
        super().__init__(parent)
        self._hotkey_str = hotkey_str
        self._listener = None
        self._thread: Optional[threading.Thread] = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start listening for the global hotkey."""
        self._stop_listener()

        pynput_key = _to_pynput_key(self._hotkey_str)
        print(f"[HotkeyManager] Listening for '{pynput_key}'")

        try:
            from pynput import keyboard as _kb

            self._listener = _kb.GlobalHotKeys(
                {pynput_key: self._on_activate}
            )
            self._thread = threading.Thread(
                target=self._listener.run,
                daemon=True,
                name="HotkeyListener",
            )
            self._thread.start()
        except Exception as exc:
            print(f"[HotkeyManager] Could not start hotkey listener: {exc}")

    def stop(self) -> None:
        self._stop_listener()

    def update_hotkey(self, hotkey_str: str) -> None:
        """Change the hotkey at runtime."""
        self._hotkey_str = hotkey_str
        self.start()  # Restart with new key

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _on_activate(self) -> None:
        # pynput calls this in its own thread; emit is thread-safe in Qt
        self.activated.emit()

    def _stop_listener(self) -> None:
        if self._listener is not None:
            try:
                self._listener.stop()
            except Exception:
                pass
            self._listener = None
