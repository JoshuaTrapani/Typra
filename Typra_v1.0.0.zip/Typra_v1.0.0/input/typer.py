# input/typer.py
"""
TextTyper — types transcribed text into the currently focused window.

Strategy
--------
1. A background thread polls GetForegroundWindow() every 50 ms.
2. Any window that is NOT the dictation app itself is saved as the
   "last target window".
3. When type_text() is called, we optionally restore focus to the
   last target window before typing.
4. pynput.keyboard.Controller.type() handles full Unicode (umlauts etc.)

Why not use SendInput directly?
pynput on Windows uses SendInput under the hood and handles Unicode
surrogate pairs correctly, so it's the right abstraction here.
"""

from __future__ import annotations

import ctypes
import threading
import time
from typing import Optional

from pynput.keyboard import Controller as KeyboardController


# Windows API via ctypes
_user32 = ctypes.windll.user32


class FocusTracker:
    """
    Tracks the last foreground window that is not our own app.

    Runs in a daemon thread, polls every 50 ms.
    """

    def __init__(self, own_hwnd: int = 0) -> None:
        self._own_hwnd: int = own_hwnd
        self._last_hwnd: int = 0
        self._lock = threading.Lock()
        self._running: bool = False
        self._thread: Optional[threading.Thread] = None

    def set_own_hwnd(self, hwnd: int) -> None:
        self._own_hwnd = hwnd

    def start(self) -> None:
        self._running = True
        self._thread = threading.Thread(
            target=self._poll, daemon=True, name="FocusTracker"
        )
        self._thread.start()

    def stop(self) -> None:
        self._running = False

    def get_last_hwnd(self) -> int:
        with self._lock:
            return self._last_hwnd

    def _poll(self) -> None:
        while self._running:
            try:
                hwnd = _user32.GetForegroundWindow()
                if hwnd and hwnd != self._own_hwnd:
                    with self._lock:
                        self._last_hwnd = hwnd
            except Exception:
                pass
            time.sleep(0.05)


class TextTyper:
    """
    Types text into the previously focused (non-dictation) window.

    Usage
    -----
        typer = TextTyper()
        typer.start_tracking(own_hwnd)   # pass our window handle
        ...
        typer.type_text("Hello World")   # types into last target window
    """

    def __init__(self) -> None:
        self._kb = KeyboardController()
        self._tracker = FocusTracker()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start_tracking(self, own_hwnd: int = 0) -> None:
        """Begin tracking foreground window changes."""
        self._tracker.set_own_hwnd(own_hwnd)
        self._tracker.start()

    def stop_tracking(self) -> None:
        self._tracker.stop()

    # ------------------------------------------------------------------
    # Typing
    # ------------------------------------------------------------------

    def type_text(
        self,
        text: str,
        trailing_space: bool = True,
        restore_focus: bool = True,
    ) -> None:
        """
        Type *text* into the target window.

        Parameters
        ----------
        text:            The string to type.
        trailing_space:  Append a space so consecutive segments flow naturally.
        restore_focus:   SetForegroundWindow to last tracked target first.
        """
        if not text:
            return

        if restore_focus:
            self._restore_focus()

        try:
            self._kb.type(text)
            if trailing_space and not text.endswith(" "):
                self._kb.type(" ")
        except Exception as exc:
            print(f"[TextTyper] Typing error: {exc}")

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _restore_focus(self) -> None:
        hwnd = self._tracker.get_last_hwnd()
        if not hwnd:
            return
        try:
            # IsIconic = window is minimised — only call ShowWindow if that's the case.
            # Calling SW_RESTORE (9) on a visible window makes it flash/minimise briefly.
            if _user32.IsIconic(hwnd):
                _user32.ShowWindow(hwnd, 9)   # SW_RESTORE — only when actually minimised

            # Attach our thread's input queue to the target so SetForegroundWindow
            # is allowed (Windows blocks it if another process "owns" foreground).
            foreground_hwnd = _user32.GetForegroundWindow()
            if foreground_hwnd and foreground_hwnd != hwnd:
                our_tid    = ctypes.windll.kernel32.GetCurrentThreadId()
                target_tid = _user32.GetWindowThreadProcessId(hwnd, None)
                fg_tid     = _user32.GetWindowThreadProcessId(foreground_hwnd, None)

                # Attach input queues so the foreground switch is permitted
                _user32.AttachThreadInput(our_tid, fg_tid, True)
                _user32.AttachThreadInput(our_tid, target_tid, True)

                _user32.BringWindowToTop(hwnd)
                _user32.SetForegroundWindow(hwnd)

                _user32.AttachThreadInput(our_tid, fg_tid, False)
                _user32.AttachThreadInput(our_tid, target_tid, False)

            time.sleep(0.05)   # Let Windows process the focus change
        except Exception as exc:
            print(f"[TextTyper] Focus restore error: {exc}")
