@echo off
TITLE Typra
cd /d "%~dp0"

REM ── Step 1: Find Python 3.11 ─────────────────────────────────────────────
py -3.11 --version >NUL 2>&1
IF ERRORLEVEL 1 (
    ECHO Python 3.11 not found.
    ECHO Download from: https://www.python.org/downloads/release/python-3119/
    PAUSE & EXIT /B 1
)

REM ── Step 2: Create virtual environment if missing ─────────────────────────
IF NOT EXIST ".venv\Scripts\activate.bat" (
    ECHO Creating virtual environment...
    py -3.11 -m venv .venv
    IF ERRORLEVEL 1 ( ECHO Failed. & PAUSE & EXIT /B 1 )
)

REM ── Step 3: Activate ──────────────────────────────────────────────────────
CALL .venv\Scripts\activate.bat

REM ── Step 4: Install dependencies if missing ───────────────────────────────
python -c "import PyQt6" >NUL 2>&1
IF ERRORLEVEL 1 (
    ECHO Installing dependencies...
    pip install -r requirements.txt
    IF ERRORLEVEL 1 ( ECHO Install failed. & PAUSE & EXIT /B 1 )
)

REM ── Step 5: Kill any old Typra instance so the log file is freed ──────────
taskkill /F /IM pythonw.exe /FI "WINDOWTITLE eq Typra*" >NUL 2>&1
timeout /t 1 /nobreak >NUL

REM ── Step 6: Launch Typra silently ────────────────────────────────────────
ECHO Starting Typra...
ECHO Look for the Typra icon in your system tray (bottom-right, click the arrow).
START "" .venv\Scripts\pythonw.exe main.py

timeout /t 4 /nobreak >NUL

REM ── Check log for errors ──────────────────────────────────────────────────
SET LOGFILE=%USERPROFILE%\.whisper_dictation\typra.log
IF EXIST "%LOGFILE%" (
    findstr /i "FATAL\|Error\|Traceback" "%LOGFILE%" >NUL 2>&1
    IF NOT ERRORLEVEL 1 (
        ECHO.
        ECHO Typra may have crashed. Last log:
        ECHO ----------------------------------------
        TYPE "%LOGFILE%"
        ECHO ----------------------------------------
        PAUSE
    ) ELSE (
        ECHO Typra started OK. This window will close.
        timeout /t 2 /nobreak >NUL
    )
)
