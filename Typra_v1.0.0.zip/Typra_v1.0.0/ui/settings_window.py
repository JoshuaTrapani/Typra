# ui/settings_window.py
from __future__ import annotations
import sys
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import (
    QComboBox, QFrame, QHBoxLayout, QLabel,
    QPushButton, QVBoxLayout, QWidget,
)
from audio.recorder import AudioRecorder
from config.settings import Settings


def _is_dark() -> bool:
    if sys.platform != "win32":
        return True
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize",
        )
        val, _ = winreg.QueryValueEx(key, "AppsUseLightTheme")
        winreg.CloseKey(key)
        return val == 0
    except Exception:
        return True


def _make_qss(dark: bool) -> str:
    if dark:
        bg       = "#16161c"
        bg2      = "#22222e"
        border   = "#3a3a50"
        text     = "#e0e0e8"
        text_dim = "#a0a0b8"
        sel      = "#3a3a70"
        btn_bg   = "#2a2a38"
        btn_fg   = "#8080a0"
        title_fg = "#e8e8ff"
        sub_fg   = "#555568"
        sec_fg   = "#c8c8e0"
    else:
        bg       = "#f5f5f7"
        bg2      = "#ffffff"
        border   = "#d0d0d8"
        text     = "#1a1a2e"
        text_dim = "#606070"
        sel      = "#c8d0f0"
        btn_bg   = "#e8e8f0"
        btn_fg   = "#505060"
        title_fg = "#1a1a2e"
        sub_fg   = "#808090"
        sec_fg   = "#2a2a3e"

    return f"""
QWidget {{
    background-color: {bg};
    color: {text};
    font-family: "Segoe UI", Arial, sans-serif;
    font-size: 13px;
}}
QComboBox {{
    background-color: {bg2};
    border: 1px solid {border};
    border-radius: 6px;
    padding: 5px 10px;
    min-height: 28px;
    color: {text};
}}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{
    background-color: {bg2};
    border: 1px solid {border};
    selection-background-color: {sel};
    color: {text};
}}
QFrame#Divider {{
    background-color: {border}; max-height: 1px; min-height: 1px;
}}
QLabel#SectionTitle {{ color: {sec_fg}; font-size: 12px; font-weight: bold; }}
QLabel#AppTitle     {{ color: {title_fg}; font-size: 17px; font-weight: bold; }}
QLabel#AppSub       {{ color: {sub_fg}; font-size: 11px; }}
QPushButton#CloseBtn {{
    background: {btn_bg}; border: 1px solid {border};
    border-radius: 5px; color: {btn_fg}; font-size: 11px;
    min-height: 28px; padding: 0 14px;
}}
QPushButton#CloseBtn:hover {{ background: {sel}; }}
"""


class SettingsWindow(QWidget):
    language_changed = pyqtSignal(str)
    mic_changed      = pyqtSignal(object)

    _LANGUAGES = [
        ("en", "English"),
        ("de", "German"),
        ("fr", "French"),
    ]

    def __init__(self, settings: Settings, app_icon: QIcon, parent=None) -> None:
        super().__init__(
            parent,
            Qt.WindowType.Window
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.WindowCloseButtonHint,
        )
        self._settings = settings
        self.setWindowTitle("Typra — Settings")
        self.setWindowIcon(app_icon)
        self.setFixedWidth(340)
        self.setFixedHeight(310)
        self._apply_theme()
        self._build_ui()

    def _apply_theme(self) -> None:
        self.setStyleSheet(_make_qss(_is_dark()))

    def refresh_theme(self) -> None:
        """Call when Windows theme changes."""
        self._apply_theme()

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 14, 18, 14)
        root.setSpacing(10)

        # Header
        hdr = QHBoxLayout()
        col = QVBoxLayout(); col.setSpacing(1)
        t = QLabel("Typra"); t.setObjectName("AppTitle")
        s = QLabel("Settings"); s.setObjectName("AppSub")
        col.addWidget(t); col.addWidget(s)
        hdr.addLayout(col); hdr.addStretch()
        root.addLayout(hdr)
        root.addWidget(self._divider())

        # Microphone
        root.addWidget(self._sec("Microphone"))
        self._mic_combo = QComboBox()
        self._populate_mics()
        self._mic_combo.currentIndexChanged.connect(self._on_mic)
        root.addWidget(self._mic_combo)

        root.addWidget(self._divider())

        # Language — plain QComboBox, same style as mic
        root.addWidget(self._sec("Language"))
        self._lang_combo = QComboBox()
        active = self._settings.language
        sel_idx = 0
        for i, (code, name) in enumerate(self._LANGUAGES):
            self._lang_combo.addItem(name, code)
            if code == active:
                sel_idx = i
        self._lang_combo.setCurrentIndex(sel_idx)
        self._lang_combo.currentIndexChanged.connect(self._on_lang)
        root.addWidget(self._lang_combo)

        root.addWidget(self._divider())

        btn = QPushButton("Close")
        btn.setObjectName("CloseBtn")
        btn.clicked.connect(self.hide)
        root.addWidget(btn)

    def _populate_mics(self) -> None:
        self._mic_combo.blockSignals(True)
        self._mic_combo.clear()
        mics = AudioRecorder.list_microphones()
        saved = self._settings.microphone_index
        if not mics:
            self._mic_combo.addItem("No microphones found", None)
        else:
            for mic in mics:
                label = mic.name[:50] + "…" if len(mic.name) > 50 else mic.name
                self._mic_combo.addItem(label, mic.index)
                if mic.index == saved:
                    self._mic_combo.setCurrentIndex(self._mic_combo.count() - 1)
        self._mic_combo.blockSignals(False)

    def _on_lang(self, _: int) -> None:
        code = self._lang_combo.currentData()
        self._settings.set("language", code)
        self.language_changed.emit(code)

    def _on_mic(self, _: int) -> None:
        idx = self._mic_combo.currentData()
        self._settings.set("microphone_index", idx)
        self.mic_changed.emit(idx)

    @staticmethod
    def _divider() -> QFrame:
        f = QFrame(); f.setObjectName("Divider")
        f.setFrameShape(QFrame.Shape.HLine)
        return f

    @staticmethod
    def _sec(text: str) -> QLabel:
        l = QLabel(text); l.setObjectName("SectionTitle")
        return l

    def closeEvent(self, e) -> None:
        e.ignore(); self.hide()
