# ui/overlay.py
"""
RecordingOverlay — small frameless pill that slides up from the bottom
of the screen during recording.

Contains:
  - Live audio waveform
  - Red stop button (red circle with white circle inside)
"""

from __future__ import annotations
from collections import deque

from PyQt6.QtCore import (
    QEasingCurve, QPoint, QPropertyAnimation,
    Qt, pyqtSignal,
)
from PyQt6.QtGui import (
    QBrush, QColor, QPainter, QPainterPath, QPen,
)
from PyQt6.QtWidgets import QApplication, QWidget


# ── Stop button ───────────────────────────────────────────────────────────────

class StopButton(QWidget):
    """Red circle with a centred white circle — fully custom painted."""

    clicked = pyqtSignal()

    def __init__(self, size: int = 36, parent=None) -> None:
        super().__init__(parent)
        self._size    = size
        self._hovered = False
        self._pressed = False
        self.setFixedSize(size, size)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def enterEvent(self, _e) -> None:
        self._hovered = True;  self.update()

    def leaveEvent(self, _e) -> None:
        self._hovered = False; self.update()

    def mousePressEvent(self, e) -> None:
        if e.button() == Qt.MouseButton.LeftButton:
            self._pressed = True;  self.update()

    def mouseReleaseEvent(self, e) -> None:
        self._pressed = False; self.update()
        if e.button() == Qt.MouseButton.LeftButton and self.rect().contains(e.pos()):
            self.clicked.emit()

    def paintEvent(self, _e) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        s = self._size

        outer = (
            QColor(150, 30, 20)  if self._pressed  else
            QColor(231, 76, 60)  if self._hovered  else
            QColor(192, 57, 43)
        )
        p.setBrush(QBrush(outer))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(0, 0, s, s)

        # Inner white circle — 40 % of diameter, perfectly centred
        d = int(s * 0.40)
        x = (s - d) // 2
        y = (s - d) // 2
        p.setBrush(QBrush(QColor(255, 255, 255, 230)))
        p.drawEllipse(x, y, d, d)


# ── Waveform widget ───────────────────────────────────────────────────────────

class WaveformWidget(QWidget):
    """Scrolling bar waveform."""

    _BAR_W      = 3
    _BAR_GAP    = 2
    _W          = 230
    _H          = 44
    _BAR_COLOR  = QColor(255, 255, 255, 200)
    _IDLE_COLOR = QColor(80, 80, 95)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setFixedSize(self._W, self._H)
        self._active  = False
        n = self._W // (self._BAR_W + self._BAR_GAP)
        self._history: deque[float] = deque([0.0] * n, maxlen=n)

    def push_level(self, rms: float) -> None:
        self._history.append(max(0.0, min(1.0, rms)))
        self.update()

    def set_active(self, active: bool) -> None:
        self._active = active
        if not active:
            for i in range(len(self._history)):
                self._history[i] = 0.0
        self.update()

    def paintEvent(self, _e) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor(0, 0, 0, 0))

        h   = self._H
        cx  = h / 2
        step = self._BAR_W + self._BAR_GAP

        for i, val in enumerate(self._history):
            bh = max(3, int(val * (h - 6)))
            by = int(cx - bh / 2)
            color = self._BAR_COLOR if (self._active and val > 0.02) else self._IDLE_COLOR
            p.setBrush(QBrush(color))
            p.setPen(Qt.PenStyle.NoPen)
            r = min(self._BAR_W // 2, bh // 2)
            p.drawRoundedRect(i * step, by, self._BAR_W, bh, r, r)


# ── Overlay window ────────────────────────────────────────────────────────────

class RecordingOverlay(QWidget):
    """
    Small frameless always-on-top pill that slides up from the bottom
    of the screen while recording is active.
    """

    stop_requested = pyqtSignal()

    _W = 320
    _H = 72

    def __init__(self, parent=None) -> None:
        super().__init__(
            parent,
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool,
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(self._W, self._H)
        self._animation = None
        self._build_ui()

    def _build_ui(self) -> None:
        self._wave = WaveformWidget(self)
        self._wave.move(16, (self._H - self._wave.height()) // 2)

        btn_size = 36
        self._stop_btn = StopButton(size=btn_size, parent=self)
        self._stop_btn.move(
            self._W - btn_size - 16,
            (self._H - btn_size) // 2,
        )
        self._stop_btn.clicked.connect(self.stop_requested)

    # ------------------------------------------------------------------

    def set_level(self, rms: float) -> None:
        self._wave.push_level(min(1.0, rms * 8))

    def set_status(self, _status: str) -> None:
        pass  # No label — waveform speaks for itself

    # ------------------------------------------------------------------

    def show_overlay(self) -> None:
        screen   = QApplication.primaryScreen().availableGeometry()
        x        = screen.x() + (screen.width() - self._W) // 2
        y_shown  = screen.y() + screen.height() - self._H - 16
        y_hidden = screen.y() + screen.height() + 10

        self.move(x, y_hidden)
        self._wave.set_active(True)
        self.show()
        self.raise_()

        anim = QPropertyAnimation(self, b"pos", self)
        anim.setDuration(220)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        anim.setStartValue(QPoint(x, y_hidden))
        anim.setEndValue(QPoint(x, y_shown))
        anim.start()
        self._animation = anim

    def hide_overlay(self) -> None:
        x        = self.x()
        screen   = QApplication.primaryScreen().availableGeometry()
        y_hidden = screen.y() + screen.height() + 10

        anim = QPropertyAnimation(self, b"pos", self)
        anim.setDuration(180)
        anim.setEasingCurve(QEasingCurve.Type.InCubic)
        anim.setStartValue(self.pos())
        anim.setEndValue(QPoint(x, y_hidden))
        anim.finished.connect(self._on_hide_done)
        anim.start()
        self._animation = anim

    def _on_hide_done(self) -> None:
        self._wave.set_active(False)
        self.hide()

    def paintEvent(self, _e) -> None:
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        path = QPainterPath()
        path.addRoundedRect(0, 0, self._W, self._H, 18, 18)

        p.fillPath(path, QColor(22, 22, 30, 230))
        p.setPen(QPen(QColor(255, 255, 255, 25), 1))
        p.drawPath(path)
