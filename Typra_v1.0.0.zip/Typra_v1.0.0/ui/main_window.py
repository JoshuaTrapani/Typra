# ui/main_window.py
"""
AppController — invisible coordinator.

Owns all components. No persistent visible window.
The only persistent UI is the tray icon.

Flow:
  Hotkey / tray click → _toggle_recording()
  _start_recording()  → show overlay, start audio + transcription
  _stop_recording()   → hide overlay, flush audio
"""

from __future__ import annotations

import sys
from pathlib import Path

from PyQt6.QtCore import QObject, QSettings, Qt, QThread, QTimer, pyqtSignal, pyqtSlot
from PyQt6.QtGui import (
    QCloseEvent, QColor, QFont, QIcon, QPainter, QPixmap,
)
from PyQt6.QtWidgets import QApplication, QMessageBox

from audio.recorder import AudioRecorder
from config.settings import Settings
from input.hotkey import HotkeyManager
from input.typer import TextTyper
from stt.transcriber import Transcriber
from stt.worker import TranscriptionWorker
from ui.audio_meter import AudioMeter
from ui.overlay import RecordingOverlay
from ui.settings_window import SettingsWindow
from ui.tray import SystemTray

# ── Asset paths ───────────────────────────────────────────────────────────────

_ASSETS         = Path(__file__).parent.parent / "assets"
_SVG            = _ASSETS / "logo_white.svg"
_ICO_DARK       = _ASSETS / "typra_dark.ico"    # white strokes  → dark mode
_ICO_LIGHT      = _ASSETS / "typra_light.ico"   # black strokes  → light mode

# ── Windows theme detection ───────────────────────────────────────────────────

def _windows_is_dark_mode() -> bool:
    """Return True if Windows is in dark mode (default if can't detect)."""
    if sys.platform != "win32":
        return True
    try:
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize",
        )
        value, _ = winreg.QueryValueEx(key, "AppsUseLightTheme")
        winreg.CloseKey(key)
        return value == 0   # 0 = dark mode, 1 = light mode
    except Exception:
        return True  # assume dark if we can't tell

# ── Logo helpers ──────────────────────────────────────────────────────────────

def _make_logo_pixmap(square_size: int = 40) -> QPixmap:
    """Render the SVG logo at the right colour for the current Windows theme."""
    is_dark = _windows_is_dark_mode()
    ico_path = _ICO_DARK if is_dark else _ICO_LIGHT

    px = QPixmap(square_size, square_size)
    px.fill(QColor(0, 0, 0, 0))

    if ico_path.exists():
        loaded = QPixmap(str(ico_path))
        if not loaded.isNull():
            scaled = loaded.scaled(
                square_size, square_size,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            # Centre on canvas
            x = (square_size - scaled.width())  // 2
            y = (square_size - scaled.height()) // 2
            p = QPainter(px)
            p.drawPixmap(x, y, scaled)
            p.end()
            return px

    # SVG fallback
    if _SVG.exists():
        try:
            from PyQt6.QtSvg import QSvgRenderer
            from PyQt6.QtCore import QRectF
            renderer = QSvgRenderer(_SVG.read_bytes())
            vb     = renderer.viewBox()
            svg_w  = vb.width()  if vb.width()  > 0 else 2339
            svg_h  = vb.height() if vb.height() > 0 else 2811
            aspect = svg_w / svg_h
            pad    = max(1, int(square_size * 0.08))
            avail  = square_size - 2 * pad
            draw_h = avail
            draw_w = max(1, int(avail * aspect))
            x = (square_size - draw_w) // 2
            y = (square_size - draw_h) // 2
            p = QPainter(px)
            renderer.render(p, QRectF(x, y, draw_w, draw_h))
            p.end()
        except Exception as exc:
            print(f"[Icon] SVG fallback: {exc}")
    return px


def make_app_icon() -> QIcon:
    """Build a QIcon from the ICO file matching the current Windows theme."""
    is_dark = _windows_is_dark_mode()
    ico_path = _ICO_DARK if is_dark else _ICO_LIGHT

    if ico_path.exists():
        icon = QIcon(str(ico_path))
        if not icon.isNull():
            return icon

    # Fallback: paint a circle
    icon = QIcon()
    for size in (16, 32, 48):
        px = QPixmap(size, size)
        px.fill(QColor(0, 0, 0, 0))
        p = QPainter(px)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setBrush(QColor(46, 213, 115))
        p.setPen(QColor(0, 0, 0, 0))
        m = size // 8
        p.drawEllipse(m, m, size - 2*m, size - 2*m)
        p.end()
        icon.addPixmap(px)
    return icon


# ── Model loader thread ───────────────────────────────────────────────────────

class ModelLoader(QThread):
    status_update = pyqtSignal(str)
    finished_ok   = pyqtSignal()
    finished_err  = pyqtSignal(str)

    def __init__(self, transcriber: Transcriber, parent=None) -> None:
        super().__init__(parent)
        self._transcriber = transcriber

    def run(self) -> None:
        import traceback
        try:
            self._transcriber.load(status_cb=self.status_update.emit)
            self.finished_ok.emit()
        except Exception as exc:
            full = traceback.format_exc()
            print(f"\n{'='*60}\nMODEL LOAD FAILED\n{full}{'='*60}\n")
            self.finished_err.emit(f"{type(exc).__name__}: {exc}\n\n{full}")


# ── App Controller ────────────────────────────────────────────────────────────

class AppController(QObject):
    """
    Owns all components. No persistent window.
    Entry point: create this, call start().
    """

    def __init__(self, settings: Settings) -> None:
        super().__init__()
        self._settings    = settings
        self._recording   = False
        self._model_ready = False

        # ── Icons ─────────────────────────────────────────────────────
        self._app_icon = make_app_icon()
        QApplication.instance().setWindowIcon(self._app_icon)

        # ── Core components ───────────────────────────────────────────
        self._recorder    = AudioRecorder(sample_rate=settings.sample_rate)
        self._transcriber = Transcriber(model_size=settings.model_size)
        self._typer       = TextTyper()
        self._hotkey      = HotkeyManager(hotkey_str=settings.get("hotkey"))
        self._worker      = TranscriptionWorker(
            recorder=self._recorder,
            transcriber=self._transcriber,
            settings=settings,
        )

        # ── UI components ─────────────────────────────────────────────
        self._overlay  = RecordingOverlay()
        self._settings_win = SettingsWindow(settings, self._app_icon)
        self._tray     = SystemTray(app_icon=self._app_icon)

        # ── Wire everything ───────────────────────────────────────────
        self._wire()

    # ------------------------------------------------------------------
    # Start
    # ------------------------------------------------------------------

    def start(self) -> None:
        # Apply taskbar icon
        QTimer.singleShot(200, self._apply_taskbar_icon)

        # Show tray
        self._tray.show()

        # Start services
        self._worker.start()
        self._hotkey.start()
        self._typer.start_tracking(0)   # HWND 0 = no exclusion yet (no window)

        # Load model in background
        self._model_loader = ModelLoader(self._transcriber)
        self._model_loader.status_update.connect(self._on_loader_status)
        self._model_loader.finished_ok.connect(self._on_model_loaded)
        self._model_loader.finished_err.connect(self._on_model_error)
        self._model_loader.start()

        # Poll for Windows theme changes every 3 s and update icon
        self._last_dark_mode = _windows_is_dark_mode()
        self._theme_timer = QTimer()
        self._theme_timer.setInterval(3000)
        self._theme_timer.timeout.connect(self._check_theme)
        self._theme_timer.start()

    @pyqtSlot()
    def _check_theme(self) -> None:
        """Detect Windows dark/light mode switch and refresh the icon."""
        is_dark = _windows_is_dark_mode()
        if is_dark != self._last_dark_mode:
            self._last_dark_mode = is_dark
            self._refresh_icon()

    def _refresh_icon(self) -> None:
        new_icon = make_app_icon()
        self._app_icon = new_icon
        QApplication.instance().setWindowIcon(new_icon)
        self._tray.setIcon(new_icon)
        self._settings_win.setWindowIcon(new_icon)
        self._settings_win.refresh_theme()   # also update bg colours
        QTimer.singleShot(100, self._apply_taskbar_icon)
        print(f"[Theme] Switched to {'dark' if self._last_dark_mode else 'light'} mode icon.")

    # ------------------------------------------------------------------
    # Signal wiring
    # ------------------------------------------------------------------

    def _wire(self) -> None:
        # Tray
        self._tray.toggle_recording.connect(self._toggle_recording)
        self._tray.open_settings.connect(self._open_settings)
        self._tray.quit_app.connect(self._quit)

        # Overlay stop button
        self._overlay.stop_requested.connect(self._stop_recording)

        # Hotkey
        self._hotkey.activated.connect(self._toggle_recording)

        # Audio level → overlay waveform
        self._recorder.set_level_callback(self._overlay.set_level)

        # Worker
        self._worker.text_ready.connect(self._on_text_ready)
        self._worker.status_changed.connect(self._on_worker_status)

        # Settings window signals
        self._settings_win.language_changed.connect(
            lambda _: None   # settings already saved by SettingsWindow
        )
        self._settings_win.mic_changed.connect(self._on_mic_changed)

    # ------------------------------------------------------------------
    # Recording
    # ------------------------------------------------------------------

    @pyqtSlot()
    def _toggle_recording(self) -> None:
        if not self._model_ready:
            return
        if self._recording:
            self._stop_recording()
        else:
            self._start_recording()

    def _start_recording(self) -> None:
        if self._recording:
            return
        self._recording = True
        mic_idx = self._settings.microphone_index
        try:
            self._recorder.start(device_index=mic_idx)
        except Exception as exc:
            self._recording = False
            self._tray.showMessage("Typra — Mic Error", str(exc), 3000)
            return
        self._worker.start_transcribing()
        self._overlay.show_overlay()
        self._tray.update_recording_state(True)

    @pyqtSlot()
    def _stop_recording(self) -> None:
        if not self._recording:
            return
        self._recording = False
        self._worker.stop_transcribing()
        self._recorder.stop()
        self._overlay.hide_overlay()
        self._tray.update_recording_state(False)

    # ------------------------------------------------------------------
    # Slots
    # ------------------------------------------------------------------

    @pyqtSlot(str)
    def _on_loader_status(self, msg: str) -> None:
        self._tray.setToolTip(f"Typra — {msg}")
        print(f"[Model] {msg}")

    @pyqtSlot()
    def _on_model_loaded(self) -> None:
        self._model_ready = True
        self._tray.set_model_ready()
        print("[Typra] Model ready.")

    @pyqtSlot(str)
    def _on_model_error(self, err: str) -> None:
        print(f"\n{'='*60}\nMODEL ERROR:\n{err}\n{'='*60}\n")
        self._tray.setToolTip("Typra — Model error")
        box = QMessageBox()
        box.setWindowTitle("Typra — Model Error")
        box.setWindowIcon(self._app_icon)
        box.setIcon(QMessageBox.Icon.Critical)
        box.setTextFormat(Qt.TextFormat.RichText)
        box.setWindowFlags(
            box.windowFlags() | Qt.WindowType.WindowStaysOnTopHint
        )
        box.setText(
            "<b>The AI model failed to load.</b><br><br>"
            "Most likely fix: install <b>Microsoft Visual C++ "
            "Redistributable 2022 (x64)</b>:<br>"
            "<code>https://aka.ms/vs/17/release/vc_redist.x64.exe</code><br><br>"
            "Then restart Typra. Click <b>Show Details</b> for the full error."
        )
        box.setDetailedText(err)
        box.exec()

    @pyqtSlot(str)
    def _on_text_ready(self, text: str) -> None:
        if text:
            self._typer.type_text(
                text,
                trailing_space=self._settings.add_trailing_space,
                restore_focus=True,
            )

    @pyqtSlot(str)
    def _on_worker_status(self, status: str) -> None:
        self._overlay.set_status(status)

    @pyqtSlot(object)
    def _on_mic_changed(self, mic_idx) -> None:
        if self._recording:
            self._stop_recording()

    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------

    def _open_settings(self) -> None:
        self._settings_win.show()
        self._settings_win.raise_()
        self._settings_win.activateWindow()

    # ------------------------------------------------------------------
    # Taskbar icon
    # ------------------------------------------------------------------

    def _apply_taskbar_icon(self) -> None:
        if sys.platform != "win32":
            return
        try:
            import ctypes, tempfile, os

            is_dark  = _windows_is_dark_mode()
            ico_path = _ICO_DARK if is_dark else _ICO_LIGHT
            if not ico_path.exists():
                return

            tmp = tempfile.NamedTemporaryFile(suffix=".ico", delete=False)
            tmp.write(ico_path.read_bytes())
            tmp.close()

            IMAGE_ICON      = 1
            LR_LOADFROMFILE = 0x00000010
            WM_SETICON      = 0x0080

            hicon32 = ctypes.windll.user32.LoadImageW(
                None, tmp.name, IMAGE_ICON, 32, 32, LR_LOADFROMFILE
            )
            hicon16 = ctypes.windll.user32.LoadImageW(
                None, tmp.name, IMAGE_ICON, 16, 16, LR_LOADFROMFILE
            )
            for win in [self._settings_win, self._overlay]:
                try:
                    hwnd = int(win.winId())
                    if hicon32:
                        ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, 1, hicon32)
                    if hicon16:
                        ctypes.windll.user32.SendMessageW(hwnd, WM_SETICON, 0, hicon16)
                except Exception:
                    pass
            os.unlink(tmp.name)
            print(f"[Icon] Taskbar icon applied ({'dark' if is_dark else 'light'}).")
        except Exception as exc:
            print(f"[Icon] Taskbar icon failed: {exc}")

    # ------------------------------------------------------------------
    # Quit
    # ------------------------------------------------------------------

    def _quit(self) -> None:
        if self._recording:
            self._stop_recording()
        try:
            self._worker.stop_transcribing()
            self._worker.requestInterruption()
            self._worker.quit()
            self._worker.wait(2000)
        except Exception:
            pass
        try:
            self._transcriber.shutdown()
        except Exception:
            pass
        try:
            self._hotkey.stop()
        except Exception:
            pass
        try:
            self._typer.stop_tracking()
        except Exception:
            pass
        QApplication.quit()


# Keep backward-compatible alias so main.py import still works
MainWindow = AppController
