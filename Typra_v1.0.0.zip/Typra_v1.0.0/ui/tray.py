# ui/tray.py
"""
Typra system tray icon.
Left-click  → toggle recording
Right-click → context menu (Settings / Quit)
"""

from __future__ import annotations

from PyQt6.QtCore import pyqtSignal
from PyQt6.QtGui import QColor, QIcon, QPainter, QPixmap
from PyQt6.QtWidgets import QMenu, QSystemTrayIcon


def _make_tray_icon(recording: bool = False, loading: bool = False) -> QIcon:
    px = QPixmap(16, 16)
    px.fill(QColor(0, 0, 0, 0))
    p = QPainter(px)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    if loading:
        color = QColor(80, 130, 200)
    elif recording:
        color = QColor(220, 53, 69)
    else:
        color = QColor(46, 213, 115)
    p.setBrush(color)
    p.setPen(QColor(0, 0, 0, 50))
    p.drawEllipse(1, 1, 14, 14)
    p.end()
    return QIcon(px)


class SystemTray(QSystemTrayIcon):
    toggle_recording = pyqtSignal()
    open_settings    = pyqtSignal()
    quit_app         = pyqtSignal()

    def __init__(self, app_icon: QIcon, parent=None) -> None:
        super().__init__(parent)
        self._app_icon  = app_icon
        self._recording = False
        self._loading   = True

        # Use the real logo as tray icon
        self.setIcon(app_icon)
        self.setToolTip("Typra — Loading…")

        self._build_menu()
        self.activated.connect(self._on_activated)

    # ------------------------------------------------------------------

    def _build_menu(self) -> None:
        menu = QMenu()

        self._action_toggle = menu.addAction("Start Recording")
        self._action_toggle.setEnabled(False)
        self._action_toggle.triggered.connect(self.toggle_recording)

        menu.addSeparator()

        action_settings = menu.addAction("Settings")
        action_settings.triggered.connect(self.open_settings)

        menu.addSeparator()

        action_quit = menu.addAction("Quit Typra")
        action_quit.triggered.connect(self.quit_app)

        self.setContextMenu(menu)

    def set_model_ready(self) -> None:
        self._loading = False
        self._action_toggle.setEnabled(True)
        self._update()

    def update_recording_state(self, recording: bool) -> None:
        self._recording = recording
        self._update()

    def _update(self) -> None:
        self.setIcon(self._app_icon)   # Always use the real logo
        if self._loading:
            self.setToolTip("Typra — Loading model…")
            self._action_toggle.setText("Start Recording")
        elif self._recording:
            self._action_toggle.setText("Stop Recording")
            self.setToolTip("Typra — Recording")
        else:
            self._action_toggle.setText("Start Recording")
            self.setToolTip("Typra — Ready  (Ctrl+Shift+Space)")

    def _on_activated(self, reason: QSystemTrayIcon.ActivationReason) -> None:
        if reason in (
            QSystemTrayIcon.ActivationReason.Trigger,          # single click
            QSystemTrayIcon.ActivationReason.DoubleClick,
        ):
            self.toggle_recording.emit()
