# config/settings.py
"""
Persistent settings manager.
Stores user preferences in ~/.whisper_dictation/settings.json
"""

import json
from pathlib import Path


# Default configuration values
DEFAULTS: dict = {
    "language": "en",
    "model_size": "base",
    "local_languages": ["en", "de", "fr"],   # Pre-installed languages
    "microphone_index": None,
    "hotkey": "ctrl+shift+space",  # Global toggle hotkey
    "chunk_seconds": 3.0,          # Max audio buffer before forced flush (s)
    "silence_threshold": 0.008,    # RMS below this = silence
    "silence_seconds": 0.7,        # Silence duration to trigger flush (s)
    "sample_rate": 16000,          # Audio sample rate (Whisper requires 16 kHz)
    "add_trailing_space": True,    # Append space after each transcribed segment
    "start_minimized": False,      # Start minimized to tray
    "window_always_on_top": True,  # Keep app above other windows
    "filter_hallucinations": True, # Filter known Whisper hallucination phrases
}

# Phrases faster-whisper tends to generate on silence (hallucinations)
HALLUCINATION_PHRASES = {
    "thank you.",
    "thank you",
    "thanks for watching.",
    "thanks for watching",
    "please subscribe.",
    "like and subscribe.",
    ".",
    "...",
    "you",
}


class Settings:
    """Thread-safe settings backed by a JSON file."""

    def __init__(self) -> None:
        self._config_dir = Path.home() / ".whisper_dictation"
        self._config_file = self._config_dir / "settings.json"
        self._data: dict = DEFAULTS.copy()
        self._load()

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _load(self) -> None:
        """Load settings from disk, falling back to defaults."""
        if self._config_file.exists():
            try:
                with open(self._config_file, "r", encoding="utf-8") as fh:
                    saved = json.load(fh)
                # Merge saved values over defaults — only known keys
                # use_real_model is intentionally excluded so it never
                # survives a restart (always boot in TEST MODE)
                self._data.update(
                    {k: v for k, v in saved.items() if k in DEFAULTS}
                )
            except Exception as exc:
                print(f"[Settings] Could not load settings: {exc}")

    def save(self) -> None:
        """Persist current settings to disk."""
        self._config_dir.mkdir(parents=True, exist_ok=True)
        try:
            with open(self._config_file, "w", encoding="utf-8") as fh:
                json.dump(self._data, fh, indent=2, ensure_ascii=False)
        except Exception as exc:
            print(f"[Settings] Could not save settings: {exc}")

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    def get(self, key: str, default=None):
        return self._data.get(key, default)

    def set(self, key: str, value) -> None:
        if key in DEFAULTS:
            self._data[key] = value
            self.save()

    def __getitem__(self, key):
        return self._data[key]

    def __setitem__(self, key, value) -> None:
        self.set(key, value)

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    @property
    def language(self) -> str:
        return self._data["language"]

    @property
    def model_size(self) -> str:
        return self._data["model_size"]

    @property
    def sample_rate(self) -> int:
        return int(self._data["sample_rate"])

    @property
    def microphone_index(self):
        return self._data["microphone_index"]

    @property
    def chunk_seconds(self) -> float:
        return float(self._data["chunk_seconds"])

    @property
    def silence_threshold(self) -> float:
        return float(self._data["silence_threshold"])

    @property
    def silence_seconds(self) -> float:
        return float(self._data["silence_seconds"])

    @property
    def add_trailing_space(self) -> bool:
        return bool(self._data["add_trailing_space"])

    @property
    def filter_hallucinations(self) -> bool:
        return bool(self._data["filter_hallucinations"])

    @property
    def window_always_on_top(self) -> bool:
        return bool(self._data["window_always_on_top"])
