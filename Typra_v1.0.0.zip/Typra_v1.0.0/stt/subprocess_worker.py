# stt/subprocess_worker.py
"""
Standalone transcription process.

This script is launched as a SEPARATE PROCESS by Typra.
It owns ctranslate2 / faster-whisper entirely — they never load in the Qt process.

Communication protocol (via stdin/stdout lines):
  Parent → Child:
    LOAD <model_size> <compute_type>
    TRANSCRIBE <language> <base64-encoded float32 numpy array>
    QUIT

  Child → Parent:
    READY                        model loaded OK
    ERROR <message>              something went wrong
    TEXT <transcribed text>      transcription result
    EMPTY                        silence detected, nothing to type
"""

import sys
import os
import base64
import traceback

def main():
    # Unbuffered stdout so the parent gets lines immediately
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)

    model = None

    for raw_line in sys.stdin:
        line = raw_line.strip()
        if not line:
            continue

        if line == "QUIT":
            break

        elif line.startswith("LOAD "):
            parts = line.split(" ", 2)
            model_size   = parts[1] if len(parts) > 1 else "base"
            compute_type = parts[2] if len(parts) > 2 else "auto"
            try:
                from faster_whisper import WhisperModel
                model = WhisperModel(
                    model_size,
                    device="cpu",
                    compute_type=compute_type,
                    cpu_threads=2,
                    num_workers=1,
                )
                print("READY", flush=True)
            except Exception:
                print(f"ERROR {traceback.format_exc()}", flush=True)

        elif line.startswith("TRANSCRIBE "):
            if model is None:
                print("ERROR model not loaded", flush=True)
                continue
            try:
                # Format: TRANSCRIBE <lang> <base64_float32_bytes>
                parts = line.split(" ", 2)
                language = parts[1]
                b64_data = parts[2]

                import numpy as np
                raw_bytes = base64.b64decode(b64_data)
                audio = np.frombuffer(raw_bytes, dtype=np.float32)

                segments, _ = model.transcribe(
                    audio,
                    language=language,
                    beam_size=1,
                    best_of=1,
                    temperature=0.0,
                    vad_filter=True,
                    vad_parameters={
                        "min_silence_duration_ms": 400,
                        "speech_pad_ms": 100,
                    },
                    without_timestamps=True,
                    word_timestamps=False,
                )
                text = " ".join(seg.text.strip() for seg in segments).strip()
                if text:
                    # Encode text as base64 to avoid newline issues in the protocol
                    encoded = base64.b64encode(text.encode("utf-8")).decode("ascii")
                    print(f"TEXT {encoded}", flush=True)
                else:
                    print("EMPTY", flush=True)

            except Exception:
                print(f"ERROR {traceback.format_exc()}", flush=True)

        else:
            print(f"ERROR unknown command: {line[:80]}", flush=True)


if __name__ == "__main__":
    main()
