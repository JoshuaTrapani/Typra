"""
transcription_server.py — runs as a standalone subprocess.

The main Typra process NEVER imports ctranslate2 or faster_whisper directly.
Instead it spawns this script as a subprocess and communicates via stdin/stdout:

  Main process → server:  JSON line with base64-encoded float32 audio + language
  Server → main process:  JSON line with transcribed text or error

Protocol
--------
  Input  (one JSON per line):
    {"audio_b64": "<base64 float32 bytes>", "language": "en", "sample_rate": 16000}
    {"command": "quit"}

  Output (one JSON per line):
    {"status": "ready", "compute_type": "auto"}
    {"text": "transcribed text here"}
    {"error": "error message"}
    {"status": "quit"}

This runs in its own process so any native crash only kills this process,
not the main Typra window.
"""

import sys
import json
import base64
import traceback

import numpy as np


def main():
    model_size   = sys.argv[1] if len(sys.argv) > 1 else "base"
    compute_type = sys.argv[2] if len(sys.argv) > 2 else "auto"

    # Redirect all print/warnings to stderr so stdout stays clean for protocol
    import warnings
    warnings.filterwarnings("ignore")

    def send(obj: dict):
        line = json.dumps(obj, ensure_ascii=False)
        sys.stdout.write(line + "\n")
        sys.stdout.flush()

    def log(msg: str):
        sys.stderr.write(f"[server] {msg}\n")
        sys.stderr.flush()

    # ── Load model ────────────────────────────────────────────────────
    log(f"Loading model='{model_size}' compute_type='{compute_type}'…")
    try:
        from faster_whisper import WhisperModel
        model = WhisperModel(
            model_size,
            device="cpu",
            compute_type=compute_type,
            cpu_threads=2,
            num_workers=1,
        )
        log("Model loaded OK.")
        send({"status": "ready", "compute_type": compute_type})
    except Exception as exc:
        send({"error": f"Model load failed: {traceback.format_exc()}"})
        sys.exit(1)

    # ── Main loop — read audio, write transcriptions ──────────────────
    for raw_line in sys.stdin:
        raw_line = raw_line.strip()
        if not raw_line:
            continue

        try:
            msg = json.loads(raw_line)
        except Exception:
            send({"error": f"Bad JSON: {raw_line[:80]}"})
            continue

        if msg.get("command") == "quit":
            send({"status": "quit"})
            break

        # Decode audio
        try:
            audio_bytes = base64.b64decode(msg["audio_b64"])
            audio = np.frombuffer(audio_bytes, dtype=np.float32).copy()
            language = msg.get("language", "en")
        except Exception as exc:
            send({"error": f"Audio decode error: {exc}"})
            continue

        # Transcribe
        try:
            segments, _ = model.transcribe(
                audio,
                language=language,
                beam_size=1,
                best_of=1,
                temperature=0.0,
                vad_filter=True,
                vad_parameters={
                    "min_silence_duration_ms": 400,
                    "speech_pad_ms": 100,
                },
                without_timestamps=True,
                word_timestamps=False,
            )
            text = " ".join(seg.text.strip() for seg in segments).strip()
            send({"text": text})
        except Exception as exc:
            send({"error": f"Transcription error: {exc}"})


if __name__ == "__main__":
    main()
