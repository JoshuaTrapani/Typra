# stt/worker.py
"""
TranscriptionWorker — a QThread that continuously:

1. Drains audio chunks from AudioRecorder.audio_queue
2. Accumulates them in a buffer
3. Flushes the buffer to Transcriber when:
   - A period of silence exceeds `silence_seconds`, OR
   - The buffer has grown beyond `chunk_seconds` of audio
4. Emits the resulting text via Qt signals

This keeps the UI thread free while transcription blocks on CPU.
"""

from __future__ import annotations

import queue
import time
from typing import Optional

import numpy as np
from PyQt6.QtCore import QThread, pyqtSignal

from audio.recorder import AudioRecorder
from config.settings import HALLUCINATION_PHRASES, Settings
from stt.transcriber import Transcriber


class TranscriptionWorker(QThread):
    # ---- Signals (emitted from worker thread, connected in UI thread) ----
    text_ready = pyqtSignal(str)           # A new transcribed segment
    status_changed = pyqtSignal(str)       # "idle" | "listening" | "processing"
    error_occurred = pyqtSignal(str)       # Human-readable error message

    def __init__(
        self,
        recorder: AudioRecorder,
        transcriber: Transcriber,
        settings: Settings,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self._recorder = recorder
        self._transcriber = transcriber
        self._settings = settings
        self._active: bool = False

    # ------------------------------------------------------------------
    # Control
    # ------------------------------------------------------------------

    def start_transcribing(self) -> None:
        """Activate the transcription loop (call before or after start())."""
        self._active = True

    def stop_transcribing(self) -> None:
        """Pause the transcription loop without stopping the thread."""
        self._active = False

    # ------------------------------------------------------------------
    # Thread body
    # ------------------------------------------------------------------

    def run(self) -> None:  # noqa: C901  (complexity acceptable here)
        """
        Main loop.

        Runs until the QThread is terminated (requestInterruption / quit).
        While _active is True it accumulates audio and transcribes.
        While _active is False it simply discards incoming audio to keep
        the queue from filling up.
        """
        sr = self._settings.sample_rate

        # How many raw samples equal one "silence chunk" timeout
        # (sounddevice delivers 1024-sample blocks)
        block_samples: int = 1024

        while not self.isInterruptionRequested():
            if not self._active:
                # Drain the queue so stale audio doesn't build up
                try:
                    self._recorder.audio_queue.get(timeout=0.05)
                except queue.Empty:
                    pass
                continue

            # --- Active transcription loop ---
            self.status_changed.emit("listening")
            audio_buffer: list[np.ndarray] = []
            silence_sample_count: int = 0
            has_speech: bool = False

            max_samples = int(self._settings.chunk_seconds * sr)
            silence_samples_threshold = int(
                self._settings.silence_seconds * sr
            )
            rms_thresh = self._settings.silence_threshold

            while self._active and not self.isInterruptionRequested():
                # --- Drain one chunk from the audio queue ---
                try:
                    chunk: np.ndarray = self._recorder.audio_queue.get(
                        timeout=0.05
                    )
                except queue.Empty:
                    continue

                audio_buffer.append(chunk)

                # --- Track silence / speech ---
                rms = float(np.sqrt(np.mean(chunk ** 2)))
                is_silent = rms < rms_thresh

                if is_silent:
                    silence_sample_count += block_samples
                else:
                    silence_sample_count = 0
                    has_speech = True

                total_samples = sum(c.shape[0] for c in audio_buffer)

                # --- Decide whether to flush ---
                silence_timeout = (
                    has_speech
                    and silence_sample_count >= silence_samples_threshold
                )
                buffer_full = total_samples >= max_samples

                if (silence_timeout or buffer_full) and has_speech:
                    self._flush(audio_buffer, sr)
                    # Reset for next segment
                    audio_buffer = []
                    silence_sample_count = 0
                    has_speech = False

            # Flush whatever remains when recording is stopped
            if audio_buffer and has_speech:
                self._flush(audio_buffer, sr)

            self.status_changed.emit("idle")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _flush(self, buffer: list[np.ndarray], sr: int) -> None:
        """Concatenate buffer, transcribe, emit result."""
        audio = np.concatenate(buffer)
        self.status_changed.emit("processing")

        text = self._transcriber.transcribe(
            audio, language=self._settings.language
        )

        if text:
            text = self._clean(text)
            if text:
                self.text_ready.emit(text)

        self.status_changed.emit("listening")

    def _clean(self, text: str) -> str:
        """
        Post-process transcribed text.

        - Strip leading/trailing whitespace.
        - Filter known faster-whisper hallucination phrases on silence.
        """
        text = text.strip()

        if self._settings.filter_hallucinations:
            if text.lower() in HALLUCINATION_PHRASES:
                print(f"[Worker] Filtered hallucination: '{text}'")
                return ""

        # Collapse multiple spaces
        import re
        text = re.sub(r"  +", " ", text)

        return text
