# stt/transcriber.py
"""
Transcriber — launches stt/subprocess_worker.py as a persistent subprocess.
All ctranslate2 / faster-whisper code runs there, never in the Qt process.
This prevents native C++ crashes (access violations) from killing the UI.
"""

from __future__ import annotations

import base64
import os
import subprocess
import sys
import threading
from pathlib import Path
from typing import Callable, Optional

import numpy as np

# ── Worker script path — works both frozen (PyInstaller) and normal ──────────
def _get_worker_script() -> list:
    """
    Returns the command to launch the subprocess worker.

    - Normal Python:  [python.exe, path/to/subprocess_worker.py]
    - Frozen .exe:    [typra.exe, --worker]   (the exe re-dispatches internally)
    """
    if getattr(sys, "frozen", False):
        # Running inside PyInstaller bundle — re-invoke ourselves with a flag
        return [sys.executable, "--worker"]
    else:
        script = Path(__file__).parent / "subprocess_worker.py"
        return [sys.executable, str(script)]


class Transcriber:

    def __init__(self, model_size: str = "base") -> None:
        self.model_size    = model_size
        self._proc: Optional[subprocess.Popen] = None
        self._loaded       = False
        self._compute_type = "auto"

    @staticmethod
    def faster_whisper_available() -> bool:
        try:
            import ctranslate2    # noqa
            import faster_whisper # noqa
            return True
        except Exception:
            return False

    def load(self, status_cb: Optional[Callable[[str], None]] = None) -> None:
        """Probe compute_type in subprocess, then start persistent worker."""
        compute_type = self._probe_compute_type(status_cb)
        if compute_type is None:
            raise RuntimeError(
                "No working compute_type found for ctranslate2 on this CPU.\n"
                "Tried: auto, float32"
            )
        self._compute_type = compute_type

        if status_cb:
            status_cb(f"Loading model '{self.model_size}' ({compute_type})…")

        print(f"[Transcriber] Starting worker subprocess (compute={compute_type})…")
        self._start_worker()
        self._send(f"LOAD {self.model_size} {compute_type}")
        response = self._readline(timeout=300)

        if response == "READY":
            self._loaded = True
            print("[Transcriber] Worker subprocess ready.")
            if status_cb:
                status_cb("Model ready — start speaking!")
        else:
            self._kill_worker()
            raise RuntimeError(f"Worker did not respond READY. Got: {response}")

    def shutdown(self) -> None:
        if self._proc is not None:
            try:
                self._send("QUIT")
            except Exception:
                pass
            try:
                self._proc.wait(timeout=3)
            except Exception:
                pass
            self._kill_worker()

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    def transcribe(self, audio: np.ndarray, language: str = "en") -> str:
        if not self._loaded or audio is None or len(audio) == 0:
            return ""
        return self._subprocess_transcribe(audio, language)

    # ------------------------------------------------------------------
    # Subprocess communication
    # ------------------------------------------------------------------

    def _start_worker(self) -> None:
        self._proc = subprocess.Popen(
            _get_worker_script(),
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True, bufsize=1, encoding="utf-8",
        )

    def _kill_worker(self) -> None:
        if self._proc is not None:
            try:
                self._proc.kill()
            except Exception:
                pass
            self._proc = None

    def _send(self, line: str) -> None:
        if self._proc and self._proc.stdin:
            self._proc.stdin.write(line + "\n")
            self._proc.stdin.flush()

    def _readline(self, timeout: float = 30.0) -> str:
        if self._proc is None:
            return "ERROR no process"
        result = [""]
        done = threading.Event()

        def _read():
            try:
                result[0] = self._proc.stdout.readline().strip()
            except Exception as exc:
                result[0] = f"ERROR {exc}"
            finally:
                done.set()

        threading.Thread(target=_read, daemon=True).start()
        return result[0] if done.wait(timeout=timeout) else "ERROR timeout"

    def _subprocess_transcribe(self, audio: np.ndarray, language: str) -> str:
        if self._proc is None or self._proc.poll() is not None:
            print("[Transcriber] Worker died — restarting…")
            try:
                self._start_worker()
                self._send(f"LOAD {self.model_size} {self._compute_type}")
                if self._readline(timeout=120) != "READY":
                    self._kill_worker()
                    return ""
            except Exception as exc:
                print(f"[Transcriber] Restart failed: {exc}")
                return ""
        try:
            b64 = base64.b64encode(audio.astype(np.float32).tobytes()).decode("ascii")
            self._send(f"TRANSCRIBE {language} {b64}")
            response = self._readline(timeout=30)
            if response.startswith("TEXT "):
                return base64.b64decode(response[5:]).decode("utf-8")
            elif response == "EMPTY":
                return ""
            elif response.startswith("ERROR"):
                print(f"[Transcriber] Worker error: {response[:200]}")
            return ""
        except Exception as exc:
            print(f"[Transcriber] error: {exc}")
            return ""

    # ------------------------------------------------------------------
    # Probe — find working compute_type without risking a crash here
    # ------------------------------------------------------------------

    def _probe_compute_type(
        self, status_cb: Optional[Callable[[str], None]] = None
    ) -> Optional[str]:
        if status_cb:
            status_cb("Checking CPU compatibility…")

        # When frozen, use --probe flag on the exe itself
        if getattr(sys, "frozen", False):
            try:
                import json as _json
                result = subprocess.run(
                    [sys.executable, "--probe", self.model_size],
                    capture_output=True, text=True, timeout=300,
                )
                stdout = result.stdout.strip()
                print(f"[Transcriber] probe: {stdout}")
                if stdout:
                    data = _json.loads(stdout)
                    if data.get("ok"):
                        return data["compute_type"]
            except Exception as exc:
                print(f"[Transcriber] Probe error: {exc}")
            return None

        # Normal Python — use a temp script
        probe_script = (
            "import sys, json\nimport numpy as np\n"
            "from faster_whisper import WhisperModel\n"
            "model_size = sys.argv[1]\n"
            "for ct in ['auto', 'float32']:\n"
            "    try:\n"
            "        m = WhisperModel(model_size, device='cpu',\n"
            "            compute_type=ct, cpu_threads=2, num_workers=1)\n"
            "        dummy = np.zeros(16000, dtype=np.float32)\n"
            "        list(m.transcribe(dummy, language='en')[0])\n"
            "        print(json.dumps({'ok': True, 'compute_type': ct}), flush=True)\n"
            "        sys.exit(0)\n"
            "    except Exception:\n"
            "        continue\n"
            "print(json.dumps({'ok': False}), flush=True)\n"
            "sys.exit(1)\n"
        )
        import tempfile, json as _json
        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, encoding="utf-8"
        )
        tmp.write(probe_script)
        tmp.close()
        try:
            result = subprocess.run(
                [sys.executable, tmp.name, self.model_size],
                capture_output=True, text=True, timeout=300,
            )
            stdout = result.stdout.strip()
            print(f"[Transcriber] probe: {stdout}")
            if result.stderr.strip():
                print(f"[Transcriber] probe stderr: {result.stderr.strip()[:200]}")
            if stdout:
                data = _json.loads(stdout)
                if data.get("ok"):
                    return data["compute_type"]
        except Exception as exc:
            print(f"[Transcriber] Probe error: {exc}")
        finally:
            try:
                os.unlink(tmp.name)
            except Exception:
                pass
        return None
